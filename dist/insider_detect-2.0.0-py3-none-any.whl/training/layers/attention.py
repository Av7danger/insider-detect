"""
Custom Attention Layer for Keras/TensorFlow

This module implements a simple attention mechanism that can be added to LSTM models
to identify which time steps (actions) are most important for the prediction.

The attention mechanism:
1. Computes attention scores for each time step
2. Applies softmax to get attention weights
3. Creates a weighted sum of LSTM outputs
4. Returns both the context vector and attention weights

Usage:
    from attention_layer import AttentionLayer
    
    # In your model
    lstm_out = LSTM(64, return_sequences=True)(embedded)
    context, attention_weights = AttentionLayer()(lstm_out)
    output = Dense(1, activation='sigmoid')(context)

Author: GitHub Copilot
Date: October 2025
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Layer


class AttentionLayer(Layer):
    """
    Custom Keras attention layer.
    
    This layer computes attention weights over sequence time steps and returns
    both the weighted context vector and the attention weights themselves.
    
    The attention mechanism uses a simple additive (Bahdanau) style:
        score = tanh(W * hidden_state)
        attention_weights = softmax(score)
        context = sum(attention_weights * hidden_states)
    
    Attributes:
        W (tf.Variable): Weight matrix for computing attention scores
        return_sequences (bool): If True, returns attention weights for visualization
    """
    
    def __init__(self, return_attention=True, **kwargs):
        """
        Initialize the attention layer.
        
        Args:
            return_attention (bool): Whether to return attention weights in addition to context.
                                    Default True for visualization purposes.
            **kwargs: Additional keras Layer arguments
        """
        super(AttentionLayer, self).__init__(**kwargs)
        self.return_attention = return_attention
        self.W = None  # Initialized in build()
    
    def build(self, input_shape):
        """
        Build the layer weights.
        
        Args:
            input_shape: Shape of input tensor (batch_size, time_steps, features)
        """
        # Get the feature dimension (last dimension of LSTM output)
        self.feature_dim = int(input_shape[-1])
        
        # Create trainable weight matrix for attention scoring
        # Shape: (feature_dim, 1)
        self.W = self.add_weight(
            name='attention_weight',
            shape=(self.feature_dim, 1),
            initializer='glorot_uniform',
            trainable=True
        )
        
        super(AttentionLayer, self).build(input_shape)
    
    def call(self, inputs, mask=None):
        """
        Forward pass of attention layer.
        
        Args:
            inputs: LSTM output tensor of shape (batch_size, time_steps, lstm_units)
            mask: Optional mask for padded sequences
        
        Returns:
            If return_attention=True: (context_vector, attention_weights)
            If return_attention=False: context_vector
            
            context_vector: shape (batch_size, lstm_units)
            attention_weights: shape (batch_size, time_steps)
        """
        # Compute attention scores
        # inputs shape: (batch_size, time_steps, lstm_units)
        # W shape: (lstm_units, 1)
        # score shape: (batch_size, time_steps, 1)
        score = K.tanh(K.dot(inputs, self.W))
        
        # Remove last dimension: (batch_size, time_steps)
        score = K.squeeze(score, axis=-1)
        
        # Apply mask if provided (for padded sequences)
        if mask is not None:
            # Convert mask to float and apply
            mask = K.cast(mask, K.floatx())
            score = score * mask + (1.0 - mask) * -1e10
        
        # Compute attention weights using softmax
        # attention_weights shape: (batch_size, time_steps)
        attention_weights = K.softmax(score, axis=-1)
        
        # Expand dims for broadcasting: (batch_size, time_steps, 1)
        attention_weights_expanded = K.expand_dims(attention_weights, axis=-1)
        
        # Compute weighted sum (context vector)
        # context shape: (batch_size, lstm_units)
        context = K.sum(inputs * attention_weights_expanded, axis=1)
        
        if self.return_attention:
            return context, attention_weights
        else:
            return context
    
    def compute_output_shape(self, input_shape):
        """
        Compute the output shape.
        
        Args:
            input_shape: (batch_size, time_steps, lstm_units)
        
        Returns:
            If return_attention=True: [(batch_size, lstm_units), (batch_size, time_steps)]
            If return_attention=False: (batch_size, lstm_units)
        """
        if self.return_attention:
            return [
                (input_shape[0], input_shape[2]),  # context vector
                (input_shape[0], input_shape[1])   # attention weights
            ]
        else:
            return (input_shape[0], input_shape[2])
    
    def get_config(self):
        """
        Get layer configuration for serialization.
        
        Returns:
            dict: Configuration dictionary
        """
        config = super(AttentionLayer, self).get_config()
        config.update({'return_attention': self.return_attention})
        return config


# Custom objects dictionary for model loading
def get_custom_objects():
    """
    Return custom objects dictionary for loading models with AttentionLayer.
    
    Usage:
        from attention_layer import get_custom_objects
        model = keras.models.load_model('model.h5', custom_objects=get_custom_objects())
    
    Returns:
        dict: Custom objects mapping
    """
    return {'AttentionLayer': AttentionLayer}


# Demo/Test function
def demo_attention_layer():
    """
    Demonstrate the attention layer with a simple example.
    """
    import numpy as np
    from tensorflow.keras.models import Model
    from tensorflow.keras.layers import Input, LSTM, Dense, Embedding
    
    print("=" * 60)
    print("Attention Layer Demo")
    print("=" * 60)
    
    # Create a simple model
    vocab_size = 100
    embed_dim = 16
    lstm_units = 32
    max_len = 10
    
    # Input
    input_layer = Input(shape=(max_len,), name='input')
    
    # Embedding
    embedded = Embedding(vocab_size, embed_dim, mask_zero=True)(input_layer)
    
    # LSTM with return_sequences=True (required for attention)
    lstm_out = LSTM(lstm_units, return_sequences=True, name='lstm')(embedded)
    
    # Attention layer
    context, attention_weights = AttentionLayer(name='attention')(lstm_out)
    
    # Output layer
    output = Dense(1, activation='sigmoid', name='output')(context)
    
    # Build model
    model = Model(inputs=input_layer, outputs=[output, attention_weights])
    model.compile(optimizer='adam', loss='binary_crossentropy')
    
    print("\nModel Summary:")
    model.summary()
    
    # Generate dummy data
    print("\nGenerating dummy prediction...")
    X_sample = np.random.randint(1, vocab_size, size=(1, max_len))
    
    # Predict
    pred, attn = model.predict(X_sample, verbose=0)
    
    print(f"\nInput sequence: {X_sample[0]}")
    print(f"Prediction: {pred[0][0]:.4f}")
    print(f"Attention weights shape: {attn.shape}")
    print(f"Attention weights: {attn[0]}")
    print(f"Sum of attention weights: {np.sum(attn[0]):.4f} (should be ~1.0)")
    
    print("\n" + "=" * 60)
    print("Attention weights show which positions the model focuses on!")
    print("=" * 60)


if __name__ == '__main__':
    demo_attention_layer()
