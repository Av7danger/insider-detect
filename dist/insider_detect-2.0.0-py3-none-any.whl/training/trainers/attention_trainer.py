"""
Train LSTM with Attention Mechanism for Insider Threat Detection

This script trains an LSTM model with an attention layer on session-level data.
The attention mechanism helps identify which actions in a sequence are most 
suspicious, providing interpretability.

Input:
    - CSV file with columns: 'actions_joined' (space-separated actions), 'label' (0/1)
    
Output:
    - models/attn/lstm_attn.h5: Trained Keras model
    - models/attn/tokenizer.pkl: Fitted tokenizer (joblib)
    - models/attn/metadata.json: Max length, vocab size, metrics

Usage:
    # Quick training (2 epochs, for demo)
    python src/train_lstm_attention.py \
        --sessions data/processed/sessions_augmented_v2.csv \
        --out-dir models/attn \
        --epochs 2 \
        --max-len 80
    
    # Full training (production)
    python src/train_lstm_attention.py \
        --sessions data/processed/sessions_augmented_v2.csv \
        --out-dir models/attn \
        --epochs 20 \
        --max-len 100 \
        --vocab-size 500

What to do if training fails:
    - Ensure TensorFlow is installed: pip install tensorflow
    - For GPU errors, set: os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
    - Reduce epochs/max-len/vocab-size for faster CPU training
    - Check CSV has 'actions_joined' and 'label' columns

Author: GitHub Copilot
Date: October 2025
"""

import os
import sys
import argparse
import json
import warnings
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix

# TensorFlow imports
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # Reduce TF logging
try:
    import tensorflow as tf
    from tensorflow.keras.models import Model
    from tensorflow.keras.layers import Input, Embedding, LSTM, Dense, Dropout
    from tensorflow.keras.preprocessing.text import Tokenizer
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
except ImportError as e:
    print("ERROR: TensorFlow not found. Install with: pip install tensorflow")
    print(f"Details: {e}")
    sys.exit(1)

# Import custom attention layer
try:
    from training.layers.attention import AttentionLayer, get_custom_objects
except ImportError:
    print("ERROR: attention layer not found in training.layers")
    sys.exit(1)

warnings.filterwarnings('ignore')


def load_and_prepare_data(sessions_path, test_size=0.2, random_state=42):
    """
    Load session data and prepare for training.
    
    Args:
        sessions_path (str): Path to CSV with 'actions_joined' and 'label' columns
        test_size (float): Proportion of test data
        random_state (int): Random seed
    
    Returns:
        tuple: (X_train, X_test, y_train, y_test, action_sequences)
    """
    print(f"\n{'='*60}")
    print("Loading Data")
    print(f"{'='*60}")
    
    # Load CSV
    if not os.path.exists(sessions_path):
        raise FileNotFoundError(f"Sessions file not found: {sessions_path}")
    
    df = pd.read_csv(sessions_path)
    print(f"✓ Loaded {len(df)} sessions from {sessions_path}")
    
    # Validate columns
    if 'actions_joined' not in df.columns:
        raise ValueError("CSV must have 'actions_joined' column")
    if 'label' not in df.columns:
        raise ValueError("CSV must have 'label' column")
    
    # Extract action sequences and labels
    action_sequences = df['actions_joined'].values
    labels = df['label'].values
    
    # Class distribution
    n_benign = (labels == 0).sum()
    n_malicious = (labels == 1).sum()
    print(f"✓ Class distribution: {n_benign} benign, {n_malicious} malicious ({n_malicious/len(labels)*100:.2f}%)")
    
    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        action_sequences, labels,
        test_size=test_size,
        random_state=random_state,
        stratify=labels
    )
    
    print(f"✓ Train: {len(X_train)} sessions")
    print(f"✓ Test: {len(X_test)} sessions")
    
    return X_train, X_test, y_train, y_test, action_sequences


def tokenize_actions(X_train, X_test, vocab_size=500):
    """
    Tokenize action sequences using Keras Tokenizer.
    
    Args:
        X_train (np.ndarray): Training action sequences (strings)
        X_test (np.ndarray): Test action sequences (strings)
        vocab_size (int): Maximum vocabulary size
    
    Returns:
        tuple: (tokenizer, vocab_size_actual)
    """
    print(f"\n{'='*60}")
    print("Tokenizing Actions")
    print(f"{'='*60}")
    
    # Initialize tokenizer
    tokenizer = Tokenizer(
        num_words=vocab_size,
        oov_token='<UNK>',
        filters='',  # Don't filter anything (actions are already clean)
        lower=False  # Keep action case
    )
    
    # Fit on training data
    tokenizer.fit_on_texts(X_train)
    
    # Get actual vocab size
    vocab_size_actual = min(len(tokenizer.word_index) + 1, vocab_size)
    
    print(f"✓ Vocabulary size: {vocab_size_actual}")
    print(f"✓ Total unique actions: {len(tokenizer.word_index)}")
    
    # Show top actions
    word_freq = sorted(tokenizer.word_counts.items(), key=lambda x: x[1], reverse=True)
    print(f"\nTop 10 actions:")
    for action, count in word_freq[:10]:
        print(f"  {action}: {count}")
    
    return tokenizer, vocab_size_actual


def create_sequences(tokenizer, X_train, X_test, max_len=100):
    """
    Convert action sequences to padded integer sequences.
    
    Args:
        tokenizer: Fitted Keras Tokenizer
        X_train (np.ndarray): Training action sequences
        X_test (np.ndarray): Test action sequences
        max_len (int): Maximum sequence length
    
    Returns:
        tuple: (X_train_seq, X_test_seq)
    """
    print(f"\n{'='*60}")
    print("Creating Sequences")
    print(f"{'='*60}")
    
    # Convert texts to sequences
    X_train_seq = tokenizer.texts_to_sequences(X_train)
    X_test_seq = tokenizer.texts_to_sequences(X_test)
    
    # Calculate sequence length stats
    train_lens = [len(seq) for seq in X_train_seq]
    print(f"✓ Sequence length stats (train):")
    print(f"  Min: {np.min(train_lens)}, Max: {np.max(train_lens)}")
    print(f"  Mean: {np.mean(train_lens):.1f}, Median: {np.median(train_lens):.1f}")
    
    # Pad sequences
    X_train_seq = pad_sequences(X_train_seq, maxlen=max_len, padding='post', truncating='post')
    X_test_seq = pad_sequences(X_test_seq, maxlen=max_len, padding='post', truncating='post')
    
    print(f"✓ Padded to max_len={max_len}")
    print(f"✓ Train shape: {X_train_seq.shape}")
    print(f"✓ Test shape: {X_test_seq.shape}")
    
    return X_train_seq, X_test_seq


def build_lstm_attention_model(vocab_size, max_len, embed_dim=32, lstm_units=64, dropout=0.3):
    """
    Build LSTM model with attention mechanism.
    
    Args:
        vocab_size (int): Size of vocabulary
        max_len (int): Maximum sequence length
        embed_dim (int): Embedding dimension
        lstm_units (int): Number of LSTM units
        dropout (float): Dropout rate
    
    Returns:
        keras.Model: Compiled model with 2 outputs (prediction, attention_weights)
    """
    print(f"\n{'='*60}")
    print("Building Model")
    print(f"{'='*60}")
    
    # Input layer
    input_layer = Input(shape=(max_len,), name='input')
    
    # Embedding layer (mask_zero=True for padding)
    embedded = Embedding(
        input_dim=vocab_size,
        output_dim=embed_dim,
        mask_zero=True,
        name='embedding'
    )(input_layer)
    
    # LSTM layer (return_sequences=True required for attention)
    lstm_out = LSTM(
        units=lstm_units,
        return_sequences=True,
        dropout=dropout,
        recurrent_dropout=dropout,
        name='lstm'
    )(embedded)
    
    # Attention layer (returns context + attention weights)
    context, attention_weights = AttentionLayer(name='attention')(lstm_out)
    
    # Dropout for regularization
    context = Dropout(dropout)(context)
    
    # Output layer
    prediction = Dense(1, activation='sigmoid', name='prediction')(context)
    
    # Build model with 2 outputs
    model = Model(
        inputs=input_layer,
        outputs=[prediction, attention_weights]
    )
    
    # Compile model (only prediction output has loss)
    model.compile(
        optimizer='adam',
        loss={'prediction': 'binary_crossentropy', 'attention': None},
        metrics={'prediction': ['accuracy']},
        loss_weights={'prediction': 1.0, 'attention': 0.0}
    )
    
    print(f"✓ Model architecture:")
    print(f"  Vocab size: {vocab_size}")
    print(f"  Max length: {max_len}")
    print(f"  Embedding dim: {embed_dim}")
    print(f"  LSTM units: {lstm_units}")
    print(f"  Dropout: {dropout}")
    
    model.summary()
    
    return model


def train_model(model, X_train, y_train, X_val, y_val, epochs=10, batch_size=32, out_dir='models/attn'):
    """
    Train the LSTM+Attention model.
    
    Args:
        model: Compiled Keras model
        X_train, y_train: Training data
        X_val, y_val: Validation data
        epochs (int): Number of epochs
        batch_size (int): Batch size
        out_dir (str): Output directory for checkpoints
    
    Returns:
        keras.callbacks.History: Training history
    """
    print(f"\n{'='*60}")
    print("Training Model")
    print(f"{'='*60}")
    
    # Create output directory
    os.makedirs(out_dir, exist_ok=True)
    
    # Callbacks
    callbacks = [
        EarlyStopping(
            monitor='val_prediction_loss',
            patience=3,
            restore_best_weights=True,
            verbose=1
        ),
        ModelCheckpoint(
            filepath=os.path.join(out_dir, 'lstm_attn_checkpoint.h5'),
            monitor='val_prediction_loss',
            save_best_only=True,
            verbose=0
        )
    ]
    
    # Train model
    # Note: We only need y_train for the prediction output
    # The attention output doesn't need labels (loss weight = 0)
    history = model.fit(
        X_train,
        {'prediction': y_train, 'attention': np.zeros((len(y_train), X_train.shape[1]))},  # Dummy attention labels
        validation_data=(X_val, {'prediction': y_val, 'attention': np.zeros((len(y_val), X_val.shape[1]))}),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=1
    )
    
    print(f"\n✓ Training complete!")
    print(f"✓ Best val loss: {min(history.history['val_prediction_loss']):.4f}")
    
    return history


def evaluate_model(model, X_test, y_test):
    """
    Evaluate model on test set.
    
    Args:
        model: Trained Keras model
        X_test: Test sequences
        y_test: Test labels
    
    Returns:
        dict: Metrics dictionary
    """
    print(f"\n{'='*60}")
    print("Evaluating Model")
    print(f"{'='*60}")
    
    # Predict (model returns [predictions, attention_weights])
    predictions, attention = model.predict(X_test, verbose=0)
    predictions = predictions.flatten()
    
    # Binary predictions
    y_pred = (predictions > 0.5).astype(int)
    
    # Metrics
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, digits=4))
    
    # ROC-AUC
    roc_auc = roc_auc_score(y_test, predictions)
    print(f"ROC-AUC Score: {roc_auc:.4f}")
    
    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    print("\nConfusion Matrix:")
    print(cm)
    
    # Calculate metrics
    tn, fp, fn, tp = cm.ravel()
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    metrics = {
        'precision': float(precision),
        'recall': float(recall),
        'f1_score': float(f1),
        'roc_auc': float(roc_auc),
        'accuracy': float((tp + tn) / (tp + tn + fp + fn))
    }
    
    print(f"\n✓ Test Metrics:")
    for key, value in metrics.items():
        print(f"  {key}: {value:.4f}")
    
    return metrics


def main():
    """Main training pipeline."""
    parser = argparse.ArgumentParser(
        description='Train LSTM with Attention for Insider Threat Detection',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Quick demo training
  python src/train_lstm_attention.py --sessions data/processed/sessions_augmented_v2.csv --epochs 2 --max-len 80
  
  # Full training
  python src/train_lstm_attention.py --sessions data/processed/sessions_augmented_v2.csv --epochs 20 --max-len 100
        """
    )
    
    parser.add_argument('--sessions', type=str, required=True,
                       help='Path to sessions CSV with actions_joined and label columns')
    parser.add_argument('--out-dir', type=str, default='models/attn',
                       help='Output directory for model artifacts (default: models/attn)')
    parser.add_argument('--max-len', type=int, default=80,
                       help='Maximum sequence length (default: 80)')
    parser.add_argument('--vocab-size', type=int, default=500,
                       help='Maximum vocabulary size (default: 500)')
    parser.add_argument('--embed-dim', type=int, default=32,
                       help='Embedding dimension (default: 32)')
    parser.add_argument('--lstm-units', type=int, default=64,
                       help='Number of LSTM units (default: 64)')
    parser.add_argument('--dropout', type=float, default=0.3,
                       help='Dropout rate (default: 0.3)')
    parser.add_argument('--epochs', type=int, default=10,
                       help='Number of training epochs (default: 10)')
    parser.add_argument('--batch-size', type=int, default=32,
                       help='Batch size (default: 32)')
    parser.add_argument('--test-size', type=float, default=0.2,
                       help='Test set proportion (default: 0.2)')
    parser.add_argument('--random-state', type=int, default=42,
                       help='Random seed (default: 42)')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("LSTM + Attention Training Pipeline")
    print("=" * 60)
    print(f"TensorFlow version: {tf.__version__}")
    print(f"GPU available: {len(tf.config.list_physical_devices('GPU')) > 0}")
    
    # Load data
    X_train, X_test, y_train, y_test, _ = load_and_prepare_data(
        args.sessions,
        test_size=args.test_size,
        random_state=args.random_state
    )
    
    # Tokenize
    tokenizer, vocab_size_actual = tokenize_actions(X_train, X_test, args.vocab_size)
    
    # Create sequences
    X_train_seq, X_test_seq = create_sequences(tokenizer, X_train, X_test, args.max_len)
    
    # Build model
    model = build_lstm_attention_model(
        vocab_size=vocab_size_actual,
        max_len=args.max_len,
        embed_dim=args.embed_dim,
        lstm_units=args.lstm_units,
        dropout=args.dropout
    )
    
    # Train model
    history = train_model(
        model,
        X_train_seq, y_train,
        X_test_seq, y_test,
        epochs=args.epochs,
        batch_size=args.batch_size,
        out_dir=args.out_dir
    )
    
    # Evaluate
    metrics = evaluate_model(model, X_test_seq, y_test)
    
    # Save artifacts
    print(f"\n{'='*60}")
    print("Saving Artifacts")
    print(f"{'='*60}")
    
    os.makedirs(args.out_dir, exist_ok=True)
    
    # Save model
    model_path = os.path.join(args.out_dir, 'lstm_attn.h5')
    model.save(model_path)
    print(f"✓ Model saved: {model_path}")
    
    # Save tokenizer
    tokenizer_path = os.path.join(args.out_dir, 'tokenizer.pkl')
    joblib.dump(tokenizer, tokenizer_path)
    print(f"✓ Tokenizer saved: {tokenizer_path}")
    
    # Save metadata
    metadata = {
        'max_len': args.max_len,
        'vocab_size': vocab_size_actual,
        'embed_dim': args.embed_dim,
        'lstm_units': args.lstm_units,
        'dropout': args.dropout,
        'epochs_trained': args.epochs,
        'metrics': metrics
    }
    
    metadata_path = os.path.join(args.out_dir, 'metadata.json')
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=2)
    print(f"✓ Metadata saved: {metadata_path}")
    
    print("\n" + "=" * 60)
    print("Training Complete! ✅")
    print("=" * 60)
    print(f"\nArtifacts saved to: {args.out_dir}/")
    print("  - lstm_attn.h5 (model)")
    print("  - tokenizer.pkl (tokenizer)")
    print("  - metadata.json (configuration + metrics)")
    print("\nNext steps:")
    print("  1. Start FastAPI: uvicorn src.api_realtime:app --port 8001")
    print("  2. Start Kafka: docker compose -f docker-compose.kafka.yml up -d")
    print("  3. Run producer: python scripts/kafka_producer.py")
    print("  4. Run consumer: python scripts/kafka_stream_consumer.py")
    print("  5. View dashboard: streamlit run dashboard/streamlit_app.py")
    print("=" * 60)


if __name__ == '__main__':
    main()
