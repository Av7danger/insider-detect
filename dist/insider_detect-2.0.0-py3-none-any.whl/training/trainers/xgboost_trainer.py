# src/train_xgboost_v3.py
"""
Train XGBoost V3 using features from feature_engineering_v2.py
Saves model and preprocessing artifacts.
Usage:
    python src/train_xgboost_v3.py --sessions data/processed/sessions_augmented.csv
"""

import argparse
import pandas as pd
import joblib
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix, precision_recall_curve, auc
from xgboost import XGBClassifier
from app.utils.features import build_features
import os
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main(args):
    sessions_path = args.sessions
    out_dir = args.out_dir
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 80)
    print("XGBoost V3 Training - Advanced Feature Engineering")
    print("=" * 80)
    print(f"Loading sessions: {sessions_path}")
    df = pd.read_csv(sessions_path)

    # ensure label column exists as int
    if 'label' not in df.columns:
        raise ValueError("sessions CSV must contain 'label' column (0/1) at session level.")
    df['label'] = df['label'].astype(int)

    print(f"Loaded {len(df)} sessions")
    print(f"  Malicious: {df['label'].sum()} ({df['label'].mean()*100:.2f}%)")
    print(f"  Normal: {(df['label']==0).sum()} ({(df['label']==0).mean()*100:.2f}%)")

    # If actions columns not present, try to reconstruct actions_list from a column 'events_json' if present
    if 'actions_list' not in df.columns and 'actions_joined' not in df.columns:
        # attempt: if there's a column 'events' with JSON list strings - skip for now
        print("Warning: actions_list/actions_joined not found. action n-grams will be empty.")
        df['actions_joined'] = ""

    # Build features (fit=True)
    print("\n" + "=" * 80)
    print("Building advanced features (25+ features)...")
    print("=" * 80)
    print("Feature groups:")
    print("  1. Temporal: hour, day_of_week, is_weekend")
    print("  2. Velocity: events_per_min, avg_event_delta_s")
    print("  3. Behavioral: action_entropy, unique_actions, unique_src_ips")
    print("  4. User baselines: z-scores and normalized deviations")
    print(f"  5. Action n-grams: up to {args.max_ngram_features} features")
    print()
    
    X, feature_names, scaler, vect, user_stats = build_features(
        df, fit=True, max_ngram_features=args.max_ngram_features
    )

    print(f"✓ Feature matrix shape: {X.shape}")
    print(f"✓ Total features: {len(feature_names)}")
    print(f"✓ Density: {X.nnz / (X.shape[0] * X.shape[1]) * 100:.2f}% non-zero")

    y = df['label'].values

    # Train-test split (stratify by label)
    print("\n" + "=" * 80)
    print("Splitting data...")
    print("=" * 80)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, stratify=y, random_state=42
    )

    # compute scale_pos_weight for XGBoost
    neg = np.sum(y_train==0)
    pos = np.sum(y_train==1)
    scale_pos_weight = float(neg / (pos + 1e-9)) if pos>0 else 1.0
    
    print(f"Train: {X_train.shape[0]} samples ({pos} malicious, {neg} normal)")
    print(f"Test:  {X_test.shape[0]} samples ({np.sum(y_test==1)} malicious, {np.sum(y_test==0)} normal)")
    print(f"Class weight (scale_pos_weight): {scale_pos_weight:.3f}")

    print("\n" + "=" * 80)
    print("Training XGBoost V3...")
    print("=" * 80)
    model = XGBClassifier(
        n_estimators=args.n_estimators,
        max_depth=args.max_depth,
        learning_rate=args.learning_rate,
        use_label_encoder=False,
        eval_metric='logloss',
        scale_pos_weight=scale_pos_weight,
        random_state=42,
        verbosity=1
    )

    model.fit(X_train, y_train)
    print("✓ Training complete")

    print("\n" + "=" * 80)
    print("Evaluating on test set...")
    print("=" * 80)
    y_pred = model.predict(X_test)
    if hasattr(model, "predict_proba"):
        y_proba = model.predict_proba(X_test)[:,1]
    else:
        y_proba = model.predict(X_test).astype(float)

    # Detailed metrics
    cm = confusion_matrix(y_test, y_pred)
    tn, fp, fn, tp = cm.ravel()
    
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    roc_auc = roc_auc_score(y_test, y_proba)
    
    # PR-AUC
    prec_curve, rec_curve, _ = precision_recall_curve(y_test, y_proba)
    pr_auc = auc(rec_curve, prec_curve)

    print("\n" + classification_report(y_test, y_pred, digits=4))
    print(f"\nConfusion Matrix:")
    print(f"                 Predicted Normal  Predicted Malicious")
    print(f"Actual Normal          {tn:4d}              {fp:4d}")
    print(f"Actual Malicious       {fn:4d}              {tp:4d}")
    print()
    print(f"ROC-AUC:       {roc_auc:.4f}")
    print(f"PR-AUC:        {pr_auc:.4f}")
    print(f"Precision:     {precision:.4f}")
    print(f"Recall:        {recall:.4f}")
    print(f"F1-Score:      {f1:.4f}")

    # Feature importance
    print("\n" + "=" * 80)
    print("Top 20 Most Important Features:")
    print("=" * 80)
    importance = model.feature_importances_
    feat_imp = pd.DataFrame({
        'feature': feature_names,
        'importance': importance
    }).sort_values('importance', ascending=False)
    
    for idx, row in feat_imp.head(20).iterrows():
        print(f"  {row['feature']:40s} {row['importance']:8.4f}")

    # Save artifacts
    print("\n" + "=" * 80)
    print("Saving model and artifacts...")
    print("=" * 80)
    
    model_path = os.path.join(out_dir, "xgb_model_v3.pkl")
    scaler_path = os.path.join(out_dir, "fe_scaler_v2.pkl")
    vect_path = os.path.join(out_dir, "action_vect_v2.pkl")
    user_stats_path = os.path.join(out_dir, "user_stats_v2.pkl")
    feat_imp_path = os.path.join(out_dir, "xgb_v3_feature_importance.csv")
    metrics_path = os.path.join(out_dir, "xgb_v3_metrics.json")

    joblib.dump(model, model_path)
    joblib.dump(scaler, scaler_path)
    joblib.dump(vect, vect_path)
    joblib.dump(user_stats, user_stats_path)
    feat_imp.to_csv(feat_imp_path, index=False)

    print(f"✓ Model:              {model_path}")
    print(f"✓ Scaler:             {scaler_path}")
    print(f"✓ Vectorizer:         {vect_path}")
    print(f"✓ User stats:         {user_stats_path}")
    print(f"✓ Feature importance: {feat_imp_path}")

    # Save metrics
    metrics = {
        "dataset": {
            "total_sessions": int(len(df)),
            "train_sessions": int(X_train.shape[0]),
            "test_sessions": int(X_test.shape[0]),
            "malicious_train": int(pos),
            "malicious_test": int(np.sum(y_test==1)),
            "malicious_rate": float(df['label'].mean())
        },
        "features": {
            "total_features": int(len(feature_names)),
            "max_ngram_features": int(args.max_ngram_features),
            "density_pct": float(X.nnz / (X.shape[0] * X.shape[1]) * 100)
        },
        "model": {
            "n_estimators": int(args.n_estimators),
            "max_depth": int(args.max_depth),
            "learning_rate": float(args.learning_rate),
            "scale_pos_weight": float(scale_pos_weight)
        },
        "performance": {
            "precision": float(precision),
            "recall": float(recall),
            "f1_score": float(f1),
            "roc_auc": float(roc_auc),
            "pr_auc": float(pr_auc),
            "confusion_matrix": {
                "tn": int(tn), "fp": int(fp),
                "fn": int(fn), "tp": int(tp)
            }
        },
        "top_features": feat_imp.head(10).to_dict('records')
    }

    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"✓ Metrics:            {metrics_path}")

    # Plot PR curve
    pr_curve_path = os.path.join(out_dir, "xgb_v3_pr_curve.png")
    plt.figure(figsize=(10, 6))
    plt.plot(rec_curve, prec_curve, label=f'PR curve (AUC = {pr_auc:.4f})', linewidth=2)
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.title('XGBoost V3 - Precision-Recall Curve', fontsize=14, fontweight='bold')
    plt.legend(loc='lower left', fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(pr_curve_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"✓ PR curve:           {pr_curve_path}")

    print("\n" + "=" * 80)
    print("✓ XGBoost V3 training complete!")
    print("=" * 80)
    print(f"\nModel ready for deployment with {len(feature_names)} advanced features")
    print(f"Performance: Precision={precision:.4f}, Recall={recall:.4f}, F1={f1:.4f}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--sessions", required=True, help="Path to session CSV (session-level)")
    parser.add_argument("--out-dir", default="models", help="Output dir for models/artifacts")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--n-estimators", type=int, default=200)
    parser.add_argument("--max-depth", type=int, default=6)
    parser.add_argument("--learning-rate", type=float, default=0.1)
    parser.add_argument("--max_ngram_features", type=int, default=200, dest="max_ngram_features")
    args = parser.parse_args()
    main(args)
