"""
Data pipeline for insider threat detection.

This module provides functions for cleaning, sessionizing, and aggregating
log data for behavioral analysis and anomaly detection.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import hashlib


def basic_cleaning(df):
    """
    Clean the raw log data.

    Args:
        df (pd.DataFrame): Raw log data

    Returns:
        pd.DataFrame: Cleaned dataframe with parsed timestamps and filled nulls
    """
    # Create a copy to avoid modifying the original
    df_clean = df.copy()

    # Parse timestamp column
    if 'timestamp' in df_clean.columns:
        df_clean['timestamp'] = pd.to_datetime(df_clean['timestamp'], errors='coerce')

    # Fill key nulls
    key_columns = ['user', 'src_ip', 'dest_ip', 'action', 'file_path']
    for col in key_columns:
        if col in df_clean.columns:
            if df_clean[col].dtype == 'object':
                df_clean[col] = df_clean[col].fillna('unknown')
            else:
                df_clean[col] = df_clean[col].fillna(0)

    # Fill outcome column if it exists
    if 'outcome' in df_clean.columns:
        df_clean['outcome'] = df_clean['outcome'].fillna('unknown')

    # Fill label column if it exists (0 for normal, 1 for malicious)
    if 'label' in df_clean.columns:
        df_clean['label'] = df_clean['label'].fillna(0).astype(int)

    return df_clean


def sessionize(df, session_timeout_minutes=30):
    """
    Add global session IDs to the dataframe based on user activity.

    Args:
        df (pd.DataFrame): Cleaned log data
        session_timeout_minutes (int): Timeout in minutes for session breaks

    Returns:
        pd.DataFrame: DataFrame with added global_session_id column
    """
    if 'timestamp' not in df.columns or 'user' not in df.columns:
        raise ValueError("DataFrame must contain 'timestamp' and 'user' columns")

    # Sort by user and timestamp
    df_sorted = df.sort_values(['user', 'timestamp']).copy()

    # Calculate time differences within each user
    df_sorted['time_diff'] = df_sorted.groupby('user')['timestamp'].diff()

    # Create session breaks where time difference exceeds threshold
    timeout_threshold = timedelta(minutes=session_timeout_minutes)
    df_sorted['new_session'] = (df_sorted['time_diff'] > timeout_threshold) | (df_sorted['time_diff'].isna())

    # Create session IDs for each user
    df_sorted['user_session_id'] = df_sorted.groupby('user')['new_session'].cumsum()

    # Create global session ID by combining user and session
    df_sorted['global_session_id'] = df_sorted.apply(
        lambda row: hashlib.md5(f"{row['user']}_{row['user_session_id']}".encode()).hexdigest()[:8],
        axis=1
    )

    # Drop helper columns
    df_sorted = df_sorted.drop(['time_diff', 'new_session', 'user_session_id'], axis=1)

    return df_sorted


def aggregate_session_features(df):
    """
    Aggregate log data into session-level features.

    Args:
        df (pd.DataFrame): Sessionized log data

    Returns:
        pd.DataFrame: Session-aggregated features
    """
    if 'global_session_id' not in df.columns:
        raise ValueError("DataFrame must contain 'global_session_id' column. Run sessionize() first.")

    # Group by session and user
    session_features = []

    for (session_id, user), group in df.groupby(['global_session_id', 'user']):
        # Basic session info
        start_ts = group['timestamp'].min()
        end_ts = group['timestamp'].max()
        duration_s = (end_ts - start_ts).total_seconds()

        # Event counts
        num_events = len(group)
        unique_actions = group['action'].nunique()
        unique_src_ips = group['src_ip'].nunique()

        # File action ratio (actions involving files vs total actions)
        file_actions = group['action'].str.contains('file|download|upload|copy|move|delete', case=False, na=False).sum()
        file_actions_ratio = file_actions / num_events if num_events > 0 else 0

        # Label (take the most common label in the session, or 1 if any malicious activity)
        if 'label' in group.columns:
            label = 1 if group['label'].any() else 0
        else:
            label = 0  # Default to normal if no label column

        session_features.append({
            'global_session_id': session_id,
            'user': user,
            'start_ts': start_ts,
            'end_ts': end_ts,
            'duration_s': duration_s,
            'num_events': num_events,
            'unique_actions': unique_actions,
            'unique_src_ips': unique_src_ips,
            'file_actions_ratio': file_actions_ratio,
            'label': label
        })

    return pd.DataFrame(session_features)


def load_and_process_data(file_path, session_timeout_minutes=30):
    """
    Complete pipeline: load, clean, sessionize, and aggregate data.

    Args:
        file_path (str): Path to raw CSV file
        session_timeout_minutes (int): Session timeout in minutes

    Returns:
        pd.DataFrame: Processed session data
    """
    # Load raw data
    df = pd.read_csv(file_path)

    # Clean data
    df_clean = basic_cleaning(df)

    # Sessionize
    df_sessionized = sessionize(df_clean, session_timeout_minutes)

    # Aggregate features
    df_sessions = aggregate_session_features(df_sessionized)

    return df_sessions
