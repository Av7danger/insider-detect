"""
Configuration management for Insider Threat Detection System.

This module provides centralized configuration loading from:
1. config/config.yaml (default settings)
2. .env file (environment-specific overrides)
3. Environment variables (highest priority)

Usage:
    from config import config
    
    host = config.get('api.host')
    port = config.get('api.port', default=8000)
"""

import os
import yaml
from pathlib import Path
from typing import Any, Optional, Dict
from dotenv import load_dotenv


class Config:
    """
    Configuration manager with layered loading:
    1. YAML config file (base)
    2. .env file (overrides)
    3. Environment variables (highest priority)
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize configuration.
        
        Args:
            config_path: Path to YAML config file. Defaults to config/config.yaml
        """
        # Load environment variables from .env file
        load_dotenv()
        
        # Load YAML configuration
        if config_path is None:
            config_path = self._find_config_file()
        
        self.config = self._load_yaml(config_path)
        self.config_path = config_path
    
    def _find_config_file(self) -> str:
        """Find config.yaml in common locations."""
        possible_paths = [
            Path('config/config.yaml'),
            Path('config.yaml'),
            Path('../config/config.yaml'),
        ]
        
        for path in possible_paths:
            if path.exists():
                return str(path)
        
        # Return default path even if it doesn't exist
        return 'config/config.yaml'
    
    def _load_yaml(self, path: str) -> Dict:
        """Load YAML configuration file."""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
        except FileNotFoundError:
            print(f"Warning: Config file not found: {path}")
            print("Using environment variables and defaults only.")
            return {}
        except yaml.YAMLError as e:
            print(f"Error parsing YAML config: {e}")
            return {}
    
    def get(self, path: str, default: Any = None) -> Any:
        """
        Get configuration value by dot notation path.
        
        Checks in order:
        1. Environment variable (uppercase with underscores)
        2. YAML config file
        3. Default value
        
        Args:
            path: Dot-separated path (e.g., 'api.host')
            default: Default value if not found
            
        Returns:
            Configuration value or default
            
        Examples:
            >>> config.get('api.host')
            '127.0.0.1'
            >>> config.get('api.port', 8000)
            8000
            >>> config.get('model.xgb_weight')
            0.6
        """
        # Check environment variable first (highest priority)
        env_key = path.upper().replace('.', '_')
        env_value = os.getenv(env_key)
        if env_value is not None:
            return self._parse_env_value(env_value)
        
        # Check YAML config
        keys = path.split('.')
        value = self.config
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        
        return value if value is not None else default
    
    def _parse_env_value(self, value: str) -> Any:
        """Parse environment variable string to appropriate type."""
        # Boolean values
        if value.lower() in ('true', 'yes', '1', 'on'):
            return True
        if value.lower() in ('false', 'no', '0', 'off'):
            return False
        
        # Numeric values
        try:
            if '.' in value:
                return float(value)
            return int(value)
        except ValueError:
            pass
        
        # String value
        return value
    
    def get_int(self, path: str, default: int = 0) -> int:
        """Get configuration value as integer."""
        value = self.get(path, default)
        try:
            return int(value)
        except (ValueError, TypeError):
            return default
    
    def get_float(self, path: str, default: float = 0.0) -> float:
        """Get configuration value as float."""
        value = self.get(path, default)
        try:
            return float(value)
        except (ValueError, TypeError):
            return default
    
    def get_bool(self, path: str, default: bool = False) -> bool:
        """Get configuration value as boolean."""
        value = self.get(path, default)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ('true', 'yes', '1', 'on')
        return bool(value)
    
    def get_path(self, path: str, default: str = '.') -> Path:
        """Get configuration value as Path object."""
        value = self.get(path, default)
        return Path(value)
    
    def reload(self):
        """Reload configuration from file."""
        self.config = self._load_yaml(self.config_path)
    
    def __repr__(self) -> str:
        return f"Config(path={self.config_path})"
    
    def dump(self) -> Dict:
        """Return full configuration dictionary (for debugging)."""
        return self.config.copy()


# Global configuration instance
config = Config()


# Convenience functions for common settings
def get_api_host() -> str:
    """Get API host."""
    return config.get('api.host', '127.0.0.1')


def get_api_port() -> int:
    """Get API port."""
    return config.get_int('api.port', 8000)


def get_model_dir() -> Path:
    """Get models directory path."""
    return config.get_path('paths.models', 'models')


def get_data_dir() -> Path:
    """Get data directory path."""
    return config.get_path('paths.data', 'data')


def get_log_dir() -> Path:
    """Get logs directory path."""
    return config.get_path('paths.logs', 'logs')


def get_db_url() -> str:
    """Get database URL."""
    return config.get('database.url', 'sqlite:///data/predictions.db')


def get_log_level() -> str:
    """Get logging level."""
    return config.get('logging.level', 'INFO')


def get_xgb_weight() -> float:
    """Get XGBoost ensemble weight."""
    return config.get_float('model.xgb_weight', 0.6)


def get_lstm_weight() -> float:
    """Get LSTM ensemble weight."""
    return config.get_float('model.lstm_weight', 0.4)


def get_threshold() -> float:
    """Get prediction threshold."""
    return config.get_float('model.threshold', 0.5)


if __name__ == '__main__':
    # Test configuration loading
    print("Configuration loaded successfully!")
    print(f"API: {get_api_host()}:{get_api_port()}")
    print(f"Model dir: {get_model_dir()}")
    print(f"Log level: {get_log_level()}")
    print(f"XGB weight: {get_xgb_weight()}")
    print(f"LSTM weight: {get_lstm_weight()}")
    print(f"Threshold: {get_threshold()}")
