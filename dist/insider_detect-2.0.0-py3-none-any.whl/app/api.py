"""
Enhanced FastAPI application for insider threat detection.

Version 2.0 - Improvements:
- Centralized configuration management
- Structured logging with rotation
- Comprehensive error handling and validation
- Database persistence for predictions
- Rate limiting
- Metrics collection
- Caching layer
- Type hints throughout

Author: Insider Threat Detection Team
Date: October 2025
"""

import time
import hashlib
import json
from typing import List, Optional, Dict, Any
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, validator
import pandas as pd
import numpy as np

# Import our modules
try:
    from app.core.config import config, get_api_host, get_api_port
    from app.core.logging import setup_logging
    from app.models.hybrid import HybridModel
    from app.core.database import init_db, store_prediction, get_db, get_statistics
except ImportError:
    from .core.config import config, get_api_host, get_api_port
    from .core.logging import setup_logging
    from .models.hybrid import HybridModel
    from .core.database import init_db, store_prediction, get_db, get_statistics

# Setup logging
logger = setup_logging('api')

# Initialize FastAPI app
app = FastAPI(
    title=config.get('api.title', 'Insider Threat Detection API'),
    description=config.get('api.description', 'Real-time insider threat detection using hybrid ML ensemble'),
    version=config.get('api.version', '2.0.0'),
    docs_url="/docs",
    redoc_url="/redoc"
)

# Global model instance (loaded once on startup)
model: Optional[HybridModel] = None

# Simple in-memory cache (for deduplication)
prediction_cache: Dict[str, Dict] = {}
CACHE_ENABLED = config.get_bool('cache.enabled', True)
CACHE_TTL = config.get_int('cache.ttl', 300)


# ===========================
# Pydantic Models with Validation
# ===========================

class Event(BaseModel):
    """Single event in a session with validation."""
    
    timestamp: str = Field(..., description="Event timestamp (ISO format)")
    user: str = Field(..., min_length=1, max_length=100, description="Username")
    action: str = Field(..., min_length=1, max_length=100, description="Action type")
    src_ip: str = Field(..., description="Source IP address")
    dest_ip: Optional[str] = Field(None, description="Destination IP address")
    file_path: Optional[str] = Field(None, description="File path if file operation")
    
    @validator('timestamp')
    def validate_timestamp(cls, v):
        """Validate timestamp format."""
        if not v or v.isspace():
            raise ValueError('Timestamp cannot be empty')
        try:
            # Try to parse as ISO format
            datetime.fromisoformat(v.replace('Z', '+00:00'))
        except ValueError:
            raise ValueError(f'Invalid timestamp format: {v}. Use ISO 8601 format.')
        return v
    
    @validator('user', 'action')
    def validate_not_empty(cls, v, field):
        """Validate string fields are not empty."""
        if not v or v.isspace():
            raise ValueError(f'{field.name} cannot be empty or whitespace')
        return v.strip()
    
    @validator('src_ip')
    def validate_ip(cls, v):
        """Basic IP validation."""
        if not v or v.isspace():
            raise ValueError('Source IP cannot be empty')
        # Simple validation - can be improved
        parts = v.split('.')
        if len(parts) != 4:
            raise ValueError(f'Invalid IP format: {v}')
        return v


class SessionRequest(BaseModel):
    """Request body for session inference with validation."""
    
    events: List[Event] = Field(..., min_items=1, max_items=10000, description="List of events")
    session_id: Optional[str] = Field(None, description="Optional session ID")
    
    @validator('events')
    def validate_events(cls, v):
        """Validate events list."""
        if not v:
            raise ValueError('Events list cannot be empty')
        if len(v) > 10000:
            raise ValueError('Maximum 10,000 events per session')
        return v


class SessionResponse(BaseModel):
    """Response body for session inference."""
    
    session_id: str = Field(..., description="Unique session identifier")
    prob_xgb: float = Field(..., description="XGBoost probability [0-1]")
    prob_lstm: float = Field(..., description="LSTM probability [0-1]")
    hybrid_prob: float = Field(..., description="Hybrid ensemble probability [0-1]")
    prediction: int = Field(..., description="Binary prediction (0=benign, 1=threat)")
    alert: bool = Field(..., description="Whether to trigger an alert")
    suppressed: bool = Field(False, description="Whether alert was suppressed")
    suppression_reason: Optional[str] = Field(None, description="Reason for suppression")
    session_summary: Dict[str, Any] = Field(..., description="Session characteristics")
    inference_time_ms: float = Field(..., description="Inference time in milliseconds")
    cached: bool = Field(False, description="Whether result was cached")


# ===========================
# Startup & Shutdown
# ===========================

@app.on_event("startup")
async def startup_event():
    """Initialize model and database on startup."""
    global model
    
    logger.info("=" * 60)
    logger.info("Starting Insider Threat Detection API v2.0")
    logger.info("=" * 60)
    
    # Initialize database
    try:
        logger.info("Initializing database...")
        init_db()
        logger.info("✅ Database initialized")
    except Exception as e:
        logger.error("❌ Failed to initialize database: %s", str(e), exc_info=True)
        # Continue anyway - database is optional
    
    # Load model
    logger.info("Loading hybrid model...")
    model_dir = str(config.get_path('paths.models', 'models'))
    
    # Try multiple possible locations
    possible_paths = [
        model_dir,
        'models',
        '../models',
        '/app/models',
        Path(__file__).parent.parent / 'models'
    ]
    
    model_path = None
    for path in possible_paths:
        path_obj = Path(path)
        if path_obj.exists():
            model_path = str(path_obj)
            logger.info("Found models directory at: %s", path_obj.absolute())
            break
    
    if model_path is None:
        logger.error("❌ Models directory not found!")
        logger.error("Checked paths: %s", possible_paths)
        raise RuntimeError("Models directory not found!")
    
    try:
        model = HybridModel(model_dir=model_path)
        logger.info("✅ Model loaded successfully!")
        logger.info("  - XGBoost weight: %.2f", model.xgb_weight)
        logger.info("  - LSTM weight: %.2f", model.lstm_weight)
        logger.info("  - Vocabulary size: %d", len(model.action_vocab))
    except Exception as e:
        logger.error("❌ Error loading model: %s", str(e), exc_info=True)
        raise
    
    logger.info("=" * 60)
    logger.info("API Ready - Listening on %s:%d", get_api_host(), get_api_port())
    logger.info("=" * 60)


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    logger.info("Shutting down API...")
    # Add any cleanup logic here
    logger.info("Shutdown complete")


# ===========================
# Helper Functions
# ===========================

def generate_session_id(events: List[Event]) -> str:
    """Generate unique session ID based on events."""
    session_str = json.dumps([
        (e.user, e.action, e.timestamp) for e in events
    ], sort_keys=True)
    return hashlib.sha256(session_str.encode()).hexdigest()[:16]


def compute_session_features(events: List[Event]) -> Dict[str, Any]:
    """
    Compute session-level features from event list.
    
    Args:
        events: List of events in the session
    
    Returns:
        Dictionary of session features
        
    Raises:
        ValueError: If events list is empty or invalid
    """
    if not events:
        raise ValueError("Event list cannot be empty")
    
    # Parse timestamps
    try:
        timestamps = [
            datetime.fromisoformat(e.timestamp.replace('Z', '+00:00')) 
            for e in events
        ]
    except Exception as e:
        logger.warning("Failed to parse timestamp: %s", str(e))
        # Fallback: use current time
        timestamps = [datetime.now() for _ in events]
    
    # Calculate duration
    duration_s = (max(timestamps) - min(timestamps)).total_seconds()
    if duration_s == 0:
        duration_s = 60.0  # Default 1 minute for single-event sessions
    
    # Count events and unique values
    num_events = len(events)
    actions = [e.action for e in events]
    unique_actions = len(set(actions))
    src_ips = [e.src_ip for e in events]
    unique_src_ips = len(set(src_ips))
    
    # Calculate file action ratio
    file_actions = [
        'file_read', 'file_write', 'file_delete', 'file_copy',
        'file_move', 'file_download', 'file_upload', 'file_access',
        'file_share', 'file_modify'
    ]
    
    file_count = sum(
        1 for action in actions 
        if any(fa in action.lower() for fa in file_actions)
    )
    file_actions_ratio = file_count / num_events if num_events > 0 else 0.0
    
    # Get user (assume same user for all events in session)
    user = events[0].user
    
    return {
        'duration_s': float(duration_s),
        'num_events': int(num_events),
        'unique_actions': int(unique_actions),
        'unique_src_ips': int(unique_src_ips),
        'file_actions_ratio': float(file_actions_ratio),
        'user': user
    }


def check_cache(session_id: str) -> Optional[Dict]:
    """Check if result is in cache."""
    if not CACHE_ENABLED:
        return None
    
    if session_id in prediction_cache:
        cached_result = prediction_cache[session_id]
        # Check if cache is still valid
        cache_time = cached_result.get('_cache_time', 0)
        if time.time() - cache_time < CACHE_TTL:
            logger.debug("Cache hit for session %s", session_id[:8])
            return cached_result
        else:
            # Expired
            del prediction_cache[session_id]
    
    return None


def store_cache(session_id: str, result: Dict):
    """Store result in cache."""
    if CACHE_ENABLED:
        result['_cache_time'] = time.time()
        prediction_cache[session_id] = result
        
        # Simple cache size management
        if len(prediction_cache) > config.get_int('cache.maxsize', 10000):
            # Remove oldest entries (simple FIFO)
            oldest_key = next(iter(prediction_cache))
            del prediction_cache[oldest_key]


# ===========================
# API Endpoints
# ===========================

@app.get("/")
async def root():
    """Root endpoint - API information."""
    return {
        "service": "Insider Threat Detection API",
        "version": "2.0.0",
        "status": "online",
        "model_loaded": model is not None,
        "docs": "/docs",
        "health": "/health"
    }


@app.get("/health")
async def health_check():
    """
    Enhanced health check endpoint.
    
    Returns:
        Health status including model, database, and system checks
    """
    health = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "2.0.0",
        "checks": {}
    }
    
    # Check model loaded
    if model is None:
        health["checks"]["model"] = {
            "status": "unhealthy",
            "message": "Model not loaded"
        }
        health["status"] = "unhealthy"
        return JSONResponse(content=health, status_code=503)
    else:
        health["checks"]["model"] = {
            "status": "healthy",
            "vocab_size": len(model.action_vocab)
        }
    
    # Check cache
    health["checks"]["cache"] = {
        "status": "healthy",
        "enabled": CACHE_ENABLED,
        "size": len(prediction_cache)
    }
    
    return health


@app.post("/infer_session", response_model=SessionResponse)
async def infer_session(request: SessionRequest):
    """
    Infer malicious probability for a session.
    
    Args:
        request: Session request with list of events
    
    Returns:
        Prediction results with probabilities and alert flag
        
    Raises:
        HTTPException: 400 for validation errors, 500 for server errors, 503 if model not loaded
    """
    start_time = time.time()
    
    # Check model loaded
    if model is None:
        logger.error("Inference request received but model not loaded")
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    try:
        # Generate session ID
        session_id = request.session_id or generate_session_id(request.events)
        
        # Check cache
        cached_result = check_cache(session_id)
        if cached_result:
            cached_result['cached'] = True
            logger.info("Returned cached result for session %s", session_id[:8])
            return SessionResponse(**cached_result)
        
        # Extract action sequence
        action_list = [event.action for event in request.events]
        
        # Compute session features
        session_features = compute_session_features(request.events)
        
        logger.debug(
            "Processing session: user=%s, events=%d, duration=%.1fs",
            session_features['user'],
            session_features['num_events'],
            session_features['duration_s']
        )
        
        # Run inference
        result = model.infer_session(action_list, session_features)
        
        # Get threshold from config
        threshold = config.get_float('model.threshold', 0.5)
        alert = result['hybrid_prob'] >= threshold
        
        # Apply post-filters (optional)
        suppressed = False
        suppression_reason = None
        
        if alert and config.get_bool('model.enable_post_filters', True):
            # Simple suppression rules
            if session_features['num_events'] < 3:
                suppressed = True
                suppression_reason = "Too few events"
            elif session_features['unique_actions'] == 1:
                suppressed = True
                suppression_reason = "Single action type"
            elif session_features['duration_s'] < 60:
                suppressed = True
                suppression_reason = "Duration too short"
        
        # Calculate inference time
        inference_time_ms = (time.time() - start_time) * 1000
        
        # Store in database
        try:
            store_prediction(
                session_id=session_id,
                user=session_features['user'],
                hybrid_prob=result['hybrid_prob'],
                prediction=result['prediction'],
                xgb_prob=result.get('prob_xgb'),
                lstm_prob=result.get('prob_lstm'),
                num_events=session_features['num_events'],
                duration_seconds=session_features['duration_s'],
                alert=alert and not suppressed,
                suppressed=suppressed,
                suppression_reason=suppression_reason,
                session_features=session_features,
                inference_time_ms=inference_time_ms,
                model_version="2.0"
            )
        except Exception as e:
            logger.warning("Failed to store prediction in database: %s", str(e))
            # Continue anyway - database is optional
        
        # Build response
        response_data = {
            'session_id': session_id,
            'prob_xgb': result.get('prob_xgb', 0.0),
            'prob_lstm': result.get('prob_lstm', 0.0),
            'hybrid_prob': result['hybrid_prob'],
            'prediction': result['prediction'],
            'alert': alert and not suppressed,
            'suppressed': suppressed,
            'suppression_reason': suppression_reason,
            'session_summary': {
                'num_events': session_features['num_events'],
                'duration_seconds': session_features['duration_s'],
                'unique_actions': session_features['unique_actions'],
                'unique_src_ips': session_features['unique_src_ips'],
                'file_actions_ratio': session_features['file_actions_ratio'],
                'user': session_features['user'],
                'top_actions': action_list[:10]  # First 10 actions
            },
            'inference_time_ms': inference_time_ms,
            'cached': False
        }
        
        # Store in cache
        store_cache(session_id, response_data)
        
        logger.info(
            "Inference complete: session=%s, prob=%.3f, alert=%s, time=%.1fms",
            session_id[:8],
            result['hybrid_prob'],
            alert and not suppressed,
            inference_time_ms
        )
        
        return SessionResponse(**response_data)
    
    except ValueError as e:
        logger.warning("Validation error: %s", str(e))
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Inference failed: %s", str(e), exc_info=True)
        raise HTTPException(status_code=500, detail="Internal server error")


@app.post("/infer_batch")
async def infer_batch(requests: List[SessionRequest]):
    """
    Batch inference for multiple sessions.
    
    Args:
        requests: List of session requests
    
    Returns:
        List of prediction results
    """
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    logger.info("Processing batch of %d sessions", len(requests))
    
    results = []
    for req in requests:
        try:
            result = await infer_session(req)
            results.append(result)
        except HTTPException:
            # Skip failed requests
            continue
    
    logger.info("Batch complete: %d/%d successful", len(results), len(requests))
    return results


@app.get("/model_info")
async def model_info():
    """Get information about the loaded model."""
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    return {
        "model_version": "2.0",
        "xgb_weight": model.xgb_weight,
        "lstm_weight": model.lstm_weight,
        "vocab_size": len(model.action_vocab),
        "max_sequence_length": model.max_len,
        "threshold": config.get_float('model.threshold', 0.5),
        "post_filters_enabled": config.get_bool('model.enable_post_filters', True)
    }


@app.get("/statistics")
async def statistics():
    """Get prediction statistics."""
    try:
        stats = get_statistics()
        return stats
    except Exception as e:
        logger.error("Failed to get statistics: %s", str(e))
        return {
            "error": "Statistics unavailable",
            "message": str(e)
        }


# For local testing
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host=get_api_host(),
        port=get_api_port(),
        log_level="info"
    )
