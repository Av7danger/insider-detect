"""
Test-facing wrapper for the hybrid model.

Allows `from hybrid import HybridModel` as used in tests by delegating to
`app.models.hybrid` implementation.
"""

from app.models.hybrid import *  # noqa: F401,F403


