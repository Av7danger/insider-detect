"""
Test-facing wrapper for database models and helpers.

Exposes `SessionPrediction`, `init_db`, etc., by delegating to
`app.core.database` where the actual implementation lives.
"""

from app.core.database import *  # noqa: F401,F403


