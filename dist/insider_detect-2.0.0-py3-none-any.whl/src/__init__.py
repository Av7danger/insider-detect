"""
Thin wrappers to expose application modules under a simple `src` import path
for tests and external scripts. This avoids coupling tests to the internal
package structure under `app/`.
"""

# Re-export common modules for convenience
from .hybrid import HybridModel, load_hybrid_model, infer_session  # noqa: F401
from .config import (
    Config,
    config,
    get_api_host,
    get_api_port,
    get_model_dir,
    get_data_dir,
    get_log_dir,
    get_db_url,
    get_log_level,
    get_xgb_weight,
    get_lstm_weight,
    get_threshold,
)  # noqa: F401
from .database import (  # noqa: F401
    SessionPrediction,
    ModelMetrics,
    init_db,
    get_db,
    store_prediction,
    get_recent_predictions,
    get_user_predictions,
    get_alerts,
    get_statistics,
)


