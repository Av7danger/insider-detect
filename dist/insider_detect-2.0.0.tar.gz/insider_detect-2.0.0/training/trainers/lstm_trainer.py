"""
LSTM sequence model training for insider threat detection.

This script trains an LSTM model on action sequences within sessions
to detect malicious behavior patterns.
"""

import pandas as pd
import numpy as np
import joblib
import os
from collections import Counter
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix
import warnings
warnings.filterwarnings('ignore')

# Import sessionization
from training.data.pipeline import basic_cleaning, sessionize


def build_action_vocabulary(df, top_k=1000):
    """
    Build vocabulary of top-K most frequent actions.
    
    Args:
        df (pd.DataFrame): Event-level data with 'action' column
        top_k (int): Number of top actions to include
    
    Returns:
        dict: Mapping from action to integer ID
    """
    action_counts = Counter(df['action'].values)
    
    # Get top K actions
    top_actions = [action for action, _ in action_counts.most_common(top_k)]
    
    # Create vocabulary (reserve 0 for padding, 1 for unknown)
    vocab = {'<PAD>': 0, '<UNK>': 1}
    for idx, action in enumerate(top_actions, start=2):
        vocab[action] = idx
    
    print(f"Built vocabulary with {len(vocab)} actions")
    print(f"Top 10 actions: {top_actions[:10]}")
    
    return vocab


def encode_sessions(df, vocab, max_len=100):
    """
    Encode each session as a sequence of action IDs.
    
    Args:
        df (pd.DataFrame): Sessionized event data
        vocab (dict): Action vocabulary
        max_len (int): Maximum sequence length
    
    Returns:
        tuple: (sequences, labels, session_ids)
    """
    if 'global_session_id' not in df.columns:
        raise ValueError("Data must be sessionized with 'global_session_id' column")
    
    sequences = []
    labels = []
    session_ids = []
    
    # Group by session
    for session_id, group in df.groupby('global_session_id'):
        # Encode actions
        action_sequence = []
        for action in group['action'].values:
            action_id = vocab.get(action, vocab['<UNK>'])
            action_sequence.append(action_id)
        
        sequences.append(action_sequence)
        
        # Get label (1 if any event in session is malicious)
        if 'label' in group.columns:
            label = 1 if group['label'].any() else 0
        else:
            label = 0
        
        labels.append(label)
        session_ids.append(session_id)
    
    # Pad sequences
    sequences_padded = pad_sequences(
        sequences, 
        maxlen=max_len, 
        padding='post', 
        truncating='post',
        value=vocab['<PAD>']
    )
    
    print(f"Encoded {len(sequences)} sessions")
    print(f"Sequence shape: {sequences_padded.shape}")
    print(f"Label distribution: {np.bincount(labels)}")
    
    return sequences_padded, np.array(labels), session_ids


def build_lstm_model(vocab_size, max_len=100, embedding_dim=32, lstm_units=64):
    """
    Build LSTM model for sequence classification.
    
    Args:
        vocab_size (int): Size of action vocabulary
        max_len (int): Maximum sequence length
        embedding_dim (int): Dimension of embedding layer
        lstm_units (int): Number of LSTM units
    
    Returns:
        keras.Model: Compiled LSTM model
    """
    model = Sequential([
        Embedding(input_dim=vocab_size, output_dim=embedding_dim, input_length=max_len),
        LSTM(lstm_units, return_sequences=False),
        Dropout(0.3),
        Dense(32, activation='relu'),
        Dropout(0.2),
        Dense(1, activation='sigmoid')
    ])
    
    model.compile(
        optimizer='adam',
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    
    return model


def train_lstm_model(data_path='data/raw/sample_logs.csv',
                     top_k=1000,
                     max_len=100,
                     test_size=0.3,
                     epochs=8,
                     batch_size=8,
                     random_state=42):
    """
    Complete LSTM training pipeline.
    
    Args:
        data_path (str): Path to raw log CSV
        top_k (int): Vocabulary size
        max_len (int): Maximum sequence length
        test_size (float): Test set proportion
        epochs (int): Number of training epochs
        batch_size (int): Batch size for training
        random_state (int): Random seed
    
    Returns:
        dict: Training results and artifacts
    """
    print("=" * 60)
    print("LSTM Sequence Model Training")
    print("=" * 60)
    
    # Load and clean data
    print(f"\n1. Loading data from: {data_path}")
    # Handle CSV with inconsistent number of fields
    df = pd.read_csv(data_path, on_bad_lines='skip')
    print(f"   Loaded {len(df)} events")
    
    df_clean = basic_cleaning(df)
    print("   Data cleaned")
    
    # Sessionize
    print("\n2. Sessionizing events...")
    df_sessionized = sessionize(df_clean, session_timeout_minutes=30)
    n_sessions = df_sessionized['global_session_id'].nunique()
    print(f"   Created {n_sessions} sessions")
    
    # Build vocabulary
    print("\n3. Building action vocabulary...")
    vocab = build_action_vocabulary(df_sessionized, top_k=top_k)
    
    # Encode sequences
    print("\n4. Encoding sequences...")
    X, y, session_ids = encode_sessions(df_sessionized, vocab, max_len=max_len)
    
    # Split data
    print(f"\n5. Splitting data (test_size={test_size})...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=test_size,
        random_state=random_state,
        stratify=y
    )
    
    print(f"   Training set: {len(X_train)} sessions")
    print(f"   Test set: {len(X_test)} sessions")
    print(f"   Train malicious ratio: {y_train.sum() / len(y_train):.2%}")
    print(f"   Test malicious ratio: {y_test.sum() / len(y_test):.2%}")
    
    # Build model
    print("\n6. Building LSTM model...")
    model = build_lstm_model(
        vocab_size=len(vocab),
        max_len=max_len,
        embedding_dim=32,
        lstm_units=64
    )
    
    print("\nModel architecture:")
    model.summary()
    
    # Train model
    print(f"\n7. Training model for {epochs} epochs...")
    history = model.fit(
        X_train, y_train,
        validation_data=(X_test, y_test),
        epochs=epochs,
        batch_size=batch_size,
        verbose=1
    )
    
    # Evaluate
    print("\n8. Evaluating model...")
    y_pred_proba = model.predict(X_test).flatten()
    y_pred = (y_pred_proba > 0.5).astype(int)
    
    # Calculate metrics
    test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)
    
    print("\n" + "=" * 60)
    print("CLASSIFICATION REPORT")
    print("=" * 60)
    print(classification_report(y_test, y_pred, target_names=['Normal', 'Malicious']))
    
    print("\n" + "=" * 60)
    print("CONFUSION MATRIX")
    print("=" * 60)
    cm = confusion_matrix(y_test, y_pred)
    print(f"                Predicted")
    print(f"                Normal  Malicious")
    print(f"Actual Normal   {cm[0][0]:6d}  {cm[0][1]:9d}")
    print(f"       Malicious{cm[1][0]:6d}  {cm[1][1]:9d}")
    
    # ROC-AUC
    try:
        roc_auc = roc_auc_score(y_test, y_pred_proba)
        print(f"\nROC-AUC Score: {roc_auc:.4f}")
    except:
        roc_auc = None
        print("\nROC-AUC: Could not compute (insufficient class diversity)")
    
    print("\n" + "=" * 60)
    print("KEY METRICS")
    print("=" * 60)
    print(f"Test Loss:     {test_loss:.4f}")
    print(f"Test Accuracy: {test_acc:.4f}")
    if roc_auc:
        print(f"ROC-AUC:       {roc_auc:.4f}")
    print("=" * 60)
    
    return {
        'model': model,
        'vocab': vocab,
        'history': history,
        'test_loss': test_loss,
        'test_accuracy': test_acc,
        'roc_auc': roc_auc,
        'max_len': max_len
    }


def save_lstm_artifacts(artifacts, model_dir='models'):
    """
    Save LSTM model and vocabulary.
    
    Args:
        artifacts (dict): Training artifacts
        model_dir (str): Directory to save files
    """
    os.makedirs(model_dir, exist_ok=True)
    
    # Save model
    model_path = os.path.join(model_dir, 'lstm_model.h5')
    artifacts['model'].save(model_path)
    print(f"\n✅ Model saved to: {model_path}")
    
    # Save vocabulary
    vocab_path = os.path.join(model_dir, 'action_vocab.pkl')
    joblib.dump(artifacts['vocab'], vocab_path)
    print(f"✅ Vocabulary saved to: {vocab_path}")
    
    # Save metadata
    metadata = {
        'vocab_size': len(artifacts['vocab']),
        'max_len': artifacts['max_len'],
        'test_accuracy': float(artifacts['test_accuracy']),
        'test_loss': float(artifacts['test_loss']),
        'roc_auc': float(artifacts['roc_auc']) if artifacts['roc_auc'] else None
    }
    
    metadata_path = os.path.join(model_dir, 'lstm_metadata.pkl')
    joblib.dump(metadata, metadata_path)
    print(f"✅ Metadata saved to: {metadata_path}")


def load_lstm_artifacts(model_dir='models'):
    """
    Load LSTM model and vocabulary.
    
    Args:
        model_dir (str): Directory containing model files
    
    Returns:
        dict: Loaded artifacts
    """
    model_path = os.path.join(model_dir, 'lstm_model.h5')
    vocab_path = os.path.join(model_dir, 'action_vocab.pkl')
    metadata_path = os.path.join(model_dir, 'lstm_metadata.pkl')
    
    model = keras.models.load_model(model_path)
    vocab = joblib.load(vocab_path)
    metadata = joblib.load(metadata_path)
    
    return {
        'model': model,
        'vocab': vocab,
        'metadata': metadata
    }


def main():
    """Main training pipeline."""
    # Train model
    artifacts = train_lstm_model(
        data_path='data/raw/sample_logs.csv',
        top_k=1000,
        max_len=100,
        test_size=0.3,
        epochs=8,
        batch_size=8,
        random_state=42
    )
    
    # Save artifacts
    save_lstm_artifacts(artifacts)
    
    print("\n" + "=" * 60)
    print("PHASE 3 COMPLETE ✅")
    print("=" * 60)
    print("\nArtifacts created:")
    print("  - models/lstm_model.h5")
    print("  - models/action_vocab.pkl")
    print("  - models/lstm_metadata.pkl")
    print("=" * 60)


if __name__ == '__main__':
    main()
