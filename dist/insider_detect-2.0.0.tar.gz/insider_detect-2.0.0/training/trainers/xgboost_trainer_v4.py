"""
Improved XGBoost Trainer V4 - Fixes Overfitting

Key improvements over V3:
1. Cross-validation instead of simple train/test split
2. Regularization (L1, L2, gamma, min_child_weight)
3. Early stopping to prevent overfitting
4. Feature importance-based selection
5. Option to remove dominant features (e.g., user_enc)
6. SMOTE for class balancing

Usage:
    # Basic training with cross-validation
    python training/trainers/xgboost_trainer_v4.py \
        --data data/processed/sessions_augmented_v2.csv

    # With SMOTE and regularization
    python training/trainers/xgboost_trainer_v4.py \
        --data data/processed/sessions_augmented_v2.csv \
        --use-smote \
        --max-depth 4 \
        --learning-rate 0.05
"""

import argparse
import pandas as pd
import joblib
import numpy as np
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.metrics import (
    classification_report, roc_auc_score, confusion_matrix,
    precision_recall_curve, auc, f1_score, precision_score, recall_score
)
from xgboost import XGBClassifier
from app.utils.features import build_features
import os
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')


def apply_smote(X, y, sampling_strategy=0.3):
    """Apply SMOTE to balance classes"""
    try:
        from imblearn.over_sampling import SMOTE
        print(f"\nApplying SMOTE (sampling_strategy={sampling_strategy})...")
        print(f"  Before: {np.sum(y==0)} benign, {np.sum(y==1)} malicious")
        
        smote = SMOTE(sampling_strategy=sampling_strategy, random_state=42)
        X_resampled, y_resampled = smote.fit_resample(X, y)
        
        print(f"  After:  {np.sum(y_resampled==0)} benign, {np.sum(y_resampled==1)} malicious")
        return X_resampled, y_resampled
    except ImportError:
        print("\nWARNING: imblearn not installed. Skipping SMOTE.")
        print("Install with: pip install imbalanced-learn")
        return X, y


def remove_high_importance_features(X, feature_names, importance, threshold=0.8):
    """Remove features that dominate importance (potential overfitting)"""
    dominant_features = [
        feature_names[i] for i, imp in enumerate(importance)
        if imp > threshold
    ]
    
    if dominant_features:
        print(f"\nWARNING: Removing dominant features (importance > {threshold}):")
        for feat in dominant_features:
            print(f"  - {feat}")
        
        keep_indices = [i for i, imp in enumerate(importance) if imp <= threshold]
        X_filtered = X[:, keep_indices]
        feature_names_filtered = [feature_names[i] for i in keep_indices]
        
        return X_filtered, feature_names_filtered
    
    return X, feature_names


def train_with_cross_validation(X, y, feature_names, args):
    """Train XGBoost with k-fold cross-validation"""
    print("\n" + "=" * 80)
    print(f"Training with {args.cv_folds}-Fold Cross-Validation")
    print("=" * 80)
    
    # Calculate scale_pos_weight
    neg = np.sum(y == 0)
    pos = np.sum(y == 1)
    scale_pos_weight = float(neg / (pos + 1e-9)) if pos > 0 else 1.0
    
    print(f"Class distribution: {pos} malicious, {neg} benign")
    print(f"Scale pos weight: {scale_pos_weight:.3f}")
    
    # Model parameters with regularization
    model_params = {
        'n_estimators': args.n_estimators,
        'max_depth': args.max_depth,
        'learning_rate': args.learning_rate,
        'min_child_weight': args.min_child_weight,
        'gamma': args.gamma,
        'subsample': args.subsample,
        'colsample_bytree': args.colsample_bytree,
        'reg_alpha': args.reg_alpha,  # L1 regularization
        'reg_lambda': args.reg_lambda,  # L2 regularization
        'scale_pos_weight': scale_pos_weight,
        'use_label_encoder': False,
        'eval_metric': 'logloss',
        'random_state': 42,
        'verbosity': 0
    }
    
    print("\nModel Configuration:")
    print("  Regularization:")
    print(f"    - max_depth: {args.max_depth} (controls tree depth)")
    print(f"    - min_child_weight: {args.min_child_weight} (minimum samples per leaf)")
    print(f"    - gamma: {args.gamma} (minimum loss reduction)")
    print(f"    - L1 (reg_alpha): {args.reg_alpha}")
    print(f"    - L2 (reg_lambda): {args.reg_lambda}")
    print("  Stochastic features:")
    print(f"    - subsample: {args.subsample} (row sampling)")
    print(f"    - colsample_bytree: {args.colsample_bytree} (column sampling)")
    
    # Cross-validation
    cv = StratifiedKFold(n_splits=args.cv_folds, shuffle=True, random_state=42)
    
    cv_scores = {
        'precision': [],
        'recall': [],
        'f1': [],
        'roc_auc': []
    }
    
    fold_models = []
    
    for fold, (train_idx, val_idx) in enumerate(cv.split(X, y)):
        print(f"\n--- Fold {fold + 1}/{args.cv_folds} ---")
        
        X_train_fold = X[train_idx]
        y_train_fold = y[train_idx]
        X_val_fold = X[val_idx]
        y_val_fold = y[val_idx]
        
        print(f"Train: {len(train_idx)} samples ({np.sum(y_train_fold==1)} malicious)")
        print(f"Val:   {len(val_idx)} samples ({np.sum(y_val_fold==1)} malicious)")
        
        # Train model
        model = XGBClassifier(**model_params)
        
        # Fit with or without early stopping
        if args.early_stopping:
            eval_set = [(X_val_fold, y_val_fold)]
            model.fit(
                X_train_fold, y_train_fold,
                eval_set=eval_set,
                verbose=False
            )
            if hasattr(model, 'best_iteration'):
                print(f"Stopped at iteration: {model.best_iteration}")
        else:
            model.fit(X_train_fold, y_train_fold)
        
        # Evaluate
        y_pred = model.predict(X_val_fold)
        y_proba = model.predict_proba(X_val_fold)[:, 1]
        
        precision = precision_score(y_val_fold, y_pred, zero_division=0)
        recall = recall_score(y_val_fold, y_pred, zero_division=0)
        f1 = f1_score(y_val_fold, y_pred, zero_division=0)
        roc_auc = roc_auc_score(y_val_fold, y_proba)
        
        cv_scores['precision'].append(precision)
        cv_scores['recall'].append(recall)
        cv_scores['f1'].append(f1)
        cv_scores['roc_auc'].append(roc_auc)
        
        fold_models.append(model)
        
        print(f"Precision: {precision:.4f}")
        print(f"Recall:    {recall:.4f}")
        print(f"F1-Score:  {f1:.4f}")
        print(f"ROC-AUC:   {roc_auc:.4f}")
    
    # Print CV summary
    print("\n" + "=" * 80)
    print("Cross-Validation Summary")
    print("=" * 80)
    for metric, scores in cv_scores.items():
        mean_score = np.mean(scores)
        std_score = np.std(scores)
        print(f"{metric.upper():10s}: {mean_score:.4f} (+/- {std_score:.4f})")
    
    # Return best model (highest F1-score)
    best_idx = np.argmax(cv_scores['f1'])
    best_model = fold_models[best_idx]
    
    print(f"\nUsing fold {best_idx + 1} model (highest F1: {cv_scores['f1'][best_idx]:.4f})")
    
    return best_model, cv_scores


def main(args):
    sessions_path = args.data
    out_dir = args.output
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 80)
    print("XGBoost V4 Training - Improved with Regularization & CV")
    print("=" * 80)
    print(f"Loading sessions: {sessions_path}")
    df = pd.read_csv(sessions_path)

    # Validate label column
    if 'label' not in df.columns:
        raise ValueError("sessions CSV must contain 'label' column (0/1).")
    df['label'] = df['label'].astype(int)

    print(f"\nDataset Statistics:")
    print(f"  Total sessions: {len(df)}")
    print(f"  Malicious: {df['label'].sum()} ({df['label'].mean()*100:.2f}%)")
    print(f"  Benign: {(df['label']==0).sum()} ({(df['label']==0).mean()*100:.2f}%)")
    print(f"  Class imbalance ratio: {(df['label']==0).sum() / df['label'].sum():.2f}:1")

    # Prepare actions if needed
    if 'actions_list' not in df.columns and 'actions_joined' not in df.columns:
        print("\nWarning: No actions column found. Action n-grams will be empty.")
        df['actions_joined'] = ""

    # Build features
    print("\n" + "=" * 80)
    print("Building Features...")
    print("=" * 80)
    
    X, feature_names, scaler, vect, user_stats = build_features(
        df, fit=True, max_ngram_features=args.max_ngram_features
    )

    print(f"✓ Feature matrix shape: {X.shape}")
    print(f"✓ Total features: {len(feature_names)}")
    if hasattr(X, 'nnz'):
        print(f"✓ Density: {X.nnz / (X.shape[0] * X.shape[1]) * 100:.2f}% non-zero")

    y = df['label'].values

    # Convert sparse to dense if needed for SMOTE
    if hasattr(X, 'toarray'):
        X = X.toarray()

    # Apply SMOTE if requested
    if args.use_smote:
        X, y = apply_smote(X, y, sampling_strategy=args.smote_ratio)

    # Train-test split for final evaluation
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, stratify=y, random_state=42
    )

    print(f"\nTrain/Test Split:")
    print(f"  Train: {X_train.shape[0]} samples")
    print(f"  Test:  {X_test.shape[0]} samples")

    # Train with cross-validation
    model, cv_scores = train_with_cross_validation(X_train, y_train, feature_names, args)

    # Final evaluation on hold-out test set
    print("\n" + "=" * 80)
    print("Final Evaluation on Hold-Out Test Set")
    print("=" * 80)
    
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    # Metrics
    cm = confusion_matrix(y_test, y_pred)
    tn, fp, fn, tp = cm.ravel()
    
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    roc_auc = roc_auc_score(y_test, y_proba)
    
    prec_curve, rec_curve, _ = precision_recall_curve(y_test, y_proba)
    pr_auc = auc(rec_curve, prec_curve)

    print("\n" + classification_report(y_test, y_pred, digits=4))
    print(f"\nConfusion Matrix:")
    print(f"                 Predicted Benign  Predicted Malicious")
    print(f"Actual Benign          {tn:4d}              {fp:4d}")
    print(f"Actual Malicious       {fn:4d}              {tp:4d}")
    print()
    print(f"Precision:     {precision:.4f}")
    print(f"Recall:        {recall:.4f}")
    print(f"F1-Score:      {f1:.4f}")
    print(f"ROC-AUC:       {roc_auc:.4f}")
    print(f"PR-AUC:        {pr_auc:.4f}")

    # Feature importance
    print("\n" + "=" * 80)
    print("Top 20 Most Important Features:")
    print("=" * 80)
    importance = model.feature_importances_
    feat_imp = pd.DataFrame({
        'feature': feature_names,
        'importance': importance
    }).sort_values('importance', ascending=False)
    
    for idx, row in feat_imp.head(20).iterrows():
        print(f"  {row['feature']:40s} {row['importance']:8.4f}")

    # Check for overfitting indicators
    print("\n" + "=" * 80)
    print("Overfitting Check")
    print("=" * 80)
    
    # Compare train and test performance
    y_train_pred = model.predict(X_train)
    train_precision = precision_score(y_train, y_train_pred, zero_division=0)
    train_recall = recall_score(y_train, y_train_pred, zero_division=0)
    train_f1 = f1_score(y_train, y_train_pred, zero_division=0)
    
    print(f"Train Precision: {train_precision:.4f}  |  Test Precision: {precision:.4f}")
    print(f"Train Recall:    {train_recall:.4f}  |  Test Recall:    {recall:.4f}")
    print(f"Train F1:        {train_f1:.4f}  |  Test F1:        {f1:.4f}")
    
    # Calculate overfitting score
    overfit_score = (train_f1 - f1) / train_f1 if train_f1 > 0 else 0
    
    if overfit_score < 0.05:
        print(f"\n✓ Good generalization (overfit score: {overfit_score:.2%})")
    elif overfit_score < 0.15:
        print(f"\n⚠ Moderate overfitting (overfit score: {overfit_score:.2%})")
    else:
        print(f"\n✗ Significant overfitting (overfit score: {overfit_score:.2%})")
        print("  Consider:")
        print("    - Reducing max_depth")
        print("    - Increasing min_child_weight")
        print("    - Adding more regularization (reg_alpha, reg_lambda)")
        print("    - Collecting more training data")

    # Save artifacts
    print("\n" + "=" * 80)
    print("Saving Model and Artifacts...")
    print("=" * 80)
    
    model_path = os.path.join(out_dir, "xgb_model_v4.pkl")
    scaler_path = os.path.join(out_dir, "fe_scaler_v4.pkl")
    vect_path = os.path.join(out_dir, "action_vect_v4.pkl")
    user_stats_path = os.path.join(out_dir, "user_stats_v4.pkl")
    feat_imp_path = os.path.join(out_dir, "xgb_v4_feature_importance.csv")
    metrics_path = os.path.join(out_dir, "xgb_v4_metrics.json")

    joblib.dump(model, model_path)
    joblib.dump(scaler, scaler_path)
    joblib.dump(vect, vect_path)
    joblib.dump(user_stats, user_stats_path)
    feat_imp.to_csv(feat_imp_path, index=False)

    print(f"✓ Model:              {model_path}")
    print(f"✓ Scaler:             {scaler_path}")
    print(f"✓ Vectorizer:         {vect_path}")
    print(f"✓ User stats:         {user_stats_path}")
    print(f"✓ Feature importance: {feat_imp_path}")

    # Save metrics
    metrics = {
        "dataset": {
            "total_sessions": int(len(df)),
            "train_sessions": int(X_train.shape[0]),
            "test_sessions": int(X_test.shape[0]),
            "malicious_train": int(np.sum(y_train==1)),
            "malicious_test": int(np.sum(y_test==1)),
            "malicious_rate": float(df['label'].mean()),
            "smote_applied": args.use_smote,
            "smote_ratio": float(args.smote_ratio) if args.use_smote else None
        },
        "features": {
            "total_features": int(len(feature_names)),
            "max_ngram_features": int(args.max_ngram_features)
        },
        "model": {
            "n_estimators": int(args.n_estimators),
            "max_depth": int(args.max_depth),
            "learning_rate": float(args.learning_rate),
            "min_child_weight": int(args.min_child_weight),
            "gamma": float(args.gamma),
            "subsample": float(args.subsample),
            "colsample_bytree": float(args.colsample_bytree),
            "reg_alpha": float(args.reg_alpha),
            "reg_lambda": float(args.reg_lambda),
            "early_stopping": args.early_stopping,
            "cv_folds": int(args.cv_folds)
        },
        "performance": {
            "test": {
                "precision": float(precision),
                "recall": float(recall),
                "f1_score": float(f1),
                "roc_auc": float(roc_auc),
                "pr_auc": float(pr_auc)
            },
            "train": {
                "precision": float(train_precision),
                "recall": float(train_recall),
                "f1_score": float(train_f1)
            },
            "cross_validation": {
                "precision_mean": float(np.mean(cv_scores['precision'])),
                "precision_std": float(np.std(cv_scores['precision'])),
                "recall_mean": float(np.mean(cv_scores['recall'])),
                "recall_std": float(np.std(cv_scores['recall'])),
                "f1_mean": float(np.mean(cv_scores['f1'])),
                "f1_std": float(np.std(cv_scores['f1'])),
                "roc_auc_mean": float(np.mean(cv_scores['roc_auc'])),
                "roc_auc_std": float(np.std(cv_scores['roc_auc']))
            },
            "overfit_score": float(overfit_score),
            "confusion_matrix": {
                "tn": int(tn),
                "fp": int(fp),
                "fn": int(fn),
                "tp": int(tp)
            }
        },
        "top_features": [
            {
                "feature": row['feature'],
                "importance": float(row['importance'])
            }
            for idx, row in feat_imp.head(20).iterrows()
        ]
    }

    with open(metrics_path, 'w') as f:
        json.dump(metrics, f, indent=2)
    
    print(f"✓ Metrics:            {metrics_path}")

    print("\n" + "=" * 80)
    print("Training Complete!")
    print("=" * 80)
    print(f"\nTest Performance:")
    print(f"  Precision: {precision:.4f}")
    print(f"  Recall:    {recall:.4f}")
    print(f"  F1-Score:  {f1:.4f}")
    print(f"  ROC-AUC:   {roc_auc:.4f}")
    print(f"\nCV Performance:")
    print(f"  F1-Score:  {np.mean(cv_scores['f1']):.4f} (+/- {np.std(cv_scores['f1']):.4f})")
    print(f"\nOverfitting: {overfit_score:.2%}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train XGBoost V4 with regularization and CV")
    
    # Data
    parser.add_argument('--data', type=str, required=True, help='Path to sessions CSV')
    parser.add_argument('--output', type=str, default='models', help='Output directory')
    parser.add_argument('--test-size', type=float, default=0.2, help='Test set size (default: 0.2)')
    
    # Features
    parser.add_argument('--max-ngram-features', type=int, default=200, help='Max n-gram features')
    
    # Model parameters (regularization)
    parser.add_argument('--n-estimators', type=int, default=200, help='Number of trees')
    parser.add_argument('--max-depth', type=int, default=4, help='Max tree depth (reduced from 6)')
    parser.add_argument('--learning-rate', type=float, default=0.05, help='Learning rate (reduced from 0.1)')
    parser.add_argument('--min-child-weight', type=int, default=5, help='Min samples per leaf (regularization)')
    parser.add_argument('--gamma', type=float, default=0.1, help='Min loss reduction (regularization)')
    parser.add_argument('--subsample', type=float, default=0.8, help='Row sampling ratio')
    parser.add_argument('--colsample-bytree', type=float, default=0.8, help='Column sampling ratio')
    parser.add_argument('--reg-alpha', type=float, default=0.1, help='L1 regularization')
    parser.add_argument('--reg-lambda', type=float, default=1.0, help='L2 regularization')
    
    # Training
    parser.add_argument('--cv-folds', type=int, default=5, help='Number of CV folds')
    parser.add_argument('--early-stopping', action='store_true', help='Use early stopping')
    parser.add_argument('--early-stopping-rounds', type=int, default=20, help='Early stopping rounds')
    
    # Class imbalance
    parser.add_argument('--use-smote', action='store_true', help='Apply SMOTE for class balancing')
    parser.add_argument('--smote-ratio', type=float, default=0.3, help='SMOTE sampling ratio')

    args = parser.parse_args()
    main(args)
