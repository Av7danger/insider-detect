"""
Test script for hybrid ensemble model.

This script tests the hybrid model on three sample sessions:
1. Benign session - normal user behavior
2. Borderline session - slightly suspicious activity
3. Malicious session - clear insider threat indicators
"""

import sys
import os
import json

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from hybrid import HybridModel


def test_benign_session(model):
    """
    Test on a benign session with normal user behavior.
    
    Args:
        model (HybridModel): Loaded hybrid model
    
    Returns:
        dict: Test results
    """
    print("\n" + "=" * 60)
    print("TEST 1: BENIGN SESSION")
    print("=" * 60)
    
    # Normal login, file access, logout pattern
    actions = ['login', 'file_access', 'file_access', 'logout']
    
    features = {
        'duration_s': 180,  # 3 minutes
        'num_events': 4,
        'unique_actions': 3,
        'unique_src_ips': 1,
        'file_actions_ratio': 0.5,
        'user': 'user001'
    }
    
    print(f"\nSession characteristics:")
    print(f"  Actions: {actions}")
    print(f"  Duration: {features['duration_s']}s ({features['duration_s']/60:.1f} min)")
    print(f"  Events: {features['num_events']}")
    print(f"  Unique actions: {features['unique_actions']}")
    print(f"  File action ratio: {features['file_actions_ratio']:.2f}")
    
    result = model.infer_session(actions, features)
    
    print(f"\nPrediction results:")
    print(f"  XGBoost probability: {result['prob_xgb']:.4f}")
    print(f"  LSTM probability: {result['prob_lstm']:.4f}")
    print(f"  Hybrid probability: {result['hybrid_prob']:.4f}")
    print(f"  Prediction: {result['prediction_label'].upper()}")
    
    return {
        'test_name': 'benign_session',
        'description': 'Normal user behavior with standard file access',
        'actions': actions,
        'features': features,
        'results': result
    }


def test_borderline_session(model):
    """
    Test on a borderline session with slightly suspicious activity.
    
    Args:
        model (HybridModel): Loaded hybrid model
    
    Returns:
        dict: Test results
    """
    print("\n" + "=" * 60)
    print("TEST 2: BORDERLINE SESSION")
    print("=" * 60)
    
    # More file operations, some copying
    actions = ['login', 'file_access', 'file_download', 'file_copy', 'file_access', 'logout']
    
    features = {
        'duration_s': 420,  # 7 minutes
        'num_events': 6,
        'unique_actions': 5,
        'unique_src_ips': 1,
        'file_actions_ratio': 0.67,
        'user': 'user002'
    }
    
    print(f"\nSession characteristics:")
    print(f"  Actions: {actions}")
    print(f"  Duration: {features['duration_s']}s ({features['duration_s']/60:.1f} min)")
    print(f"  Events: {features['num_events']}")
    print(f"  Unique actions: {features['unique_actions']}")
    print(f"  File action ratio: {features['file_actions_ratio']:.2f}")
    
    result = model.infer_session(actions, features)
    
    print(f"\nPrediction results:")
    print(f"  XGBoost probability: {result['prob_xgb']:.4f}")
    print(f"  LSTM probability: {result['prob_lstm']:.4f}")
    print(f"  Hybrid probability: {result['hybrid_prob']:.4f}")
    print(f"  Prediction: {result['prediction_label'].upper()}")
    
    return {
        'test_name': 'borderline_session',
        'description': 'Slightly elevated file activity with copying',
        'actions': actions,
        'features': features,
        'results': result
    }


def test_malicious_session(model):
    """
    Test on a malicious session with clear insider threat indicators.
    
    Args:
        model (HybridModel): Loaded hybrid model
    
    Returns:
        dict: Test results
    """
    print("\n" + "=" * 60)
    print("TEST 3: MALICIOUS SESSION")
    print("=" * 60)
    
    # Suspicious pattern: multiple file operations, sharing, external copying
    actions = [
        'login', 'file_access', 'file_copy', 'file_share', 
        'file_download', 'file_copy', 'file_share', 'logout'
    ]
    
    features = {
        'duration_s': 900,  # 15 minutes
        'num_events': 8,
        'unique_actions': 6,
        'unique_src_ips': 2,  # Multiple IPs
        'file_actions_ratio': 0.875,  # Very high file activity
        'user': 'user003'
    }
    
    print(f"\nSession characteristics:")
    print(f"  Actions: {actions}")
    print(f"  Duration: {features['duration_s']}s ({features['duration_s']/60:.1f} min)")
    print(f"  Events: {features['num_events']}")
    print(f"  Unique actions: {features['unique_actions']}")
    print(f"  File action ratio: {features['file_actions_ratio']:.2f}")
    print(f"  Multiple source IPs: {features['unique_src_ips']}")
    
    result = model.infer_session(actions, features)
    
    print(f"\nPrediction results:")
    print(f"  XGBoost probability: {result['prob_xgb']:.4f}")
    print(f"  LSTM probability: {result['prob_lstm']:.4f}")
    print(f"  Hybrid probability: {result['hybrid_prob']:.4f}")
    print(f"  Prediction: {result['prediction_label'].upper()}")
    
    return {
        'test_name': 'malicious_session',
        'description': 'High file activity with sharing and multiple IPs',
        'actions': actions,
        'features': features,
        'results': result
    }


def main():
    """Run all hybrid model tests."""
    print("=" * 60)
    print("HYBRID MODEL TEST SUITE")
    print("=" * 60)
    
    # Load hybrid model
    print("\nLoading hybrid model...")
    try:
        model = HybridModel(model_dir='../models')
    except:
        # Try alternative path
        model = HybridModel(model_dir='models')
    
    # Run tests
    test_results = []
    
    test_results.append(test_benign_session(model))
    test_results.append(test_borderline_session(model))
    test_results.append(test_malicious_session(model))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    for i, result in enumerate(test_results, 1):
        pred = result['results']
        print(f"\nTest {i}: {result['test_name']}")
        print(f"  Description: {result['description']}")
        print(f"  Hybrid probability: {pred['hybrid_prob']:.4f}")
        print(f"  Prediction: {pred['prediction_label'].upper()}")
    
    # Save results to JSON
    output_path = 'test_hybrid_results.json'
    
    # Convert results to JSON-serializable format
    json_results = []
    for result in test_results:
        json_result = {
            'test_name': result['test_name'],
            'description': result['description'],
            'actions': result['actions'],
            'features': result['features'],
            'prob_xgb': result['results']['prob_xgb'],
            'prob_lstm': result['results']['prob_lstm'],
            'hybrid_prob': result['results']['hybrid_prob'],
            'prediction': result['results']['prediction'],
            'prediction_label': result['results']['prediction_label']
        }
        json_results.append(json_result)
    
    with open(output_path, 'w') as f:
        json.dump(json_results, f, indent=2)
    
    print(f"\n✅ Test results saved to: {output_path}")
    
    print("\n" + "=" * 60)
    print("ALL TESTS COMPLETE ✅")
    print("=" * 60)


if __name__ == '__main__':
    main()
