"""
Unit tests for configuration management.

Run with: pytest tests/test_config.py -v
"""

import os
import pytest
from pathlib import Path


def test_config_imports():
    """Test that config module can be imported."""
    try:
        from src.config import Config, config
        assert config is not None
    except ImportError:
        pytest.skip("Config module not in path")


def test_config_get():
    """Test config.get() method."""
    try:
        from src.config import config
        
        # Test with default value
        value = config.get('nonexistent.key', default='test_default')
        assert value == 'test_default'
        
    except ImportError:
        pytest.skip("Config module not in path")


def test_config_get_int():
    """Test config.get_int() method."""
    try:
        from src.config import config
        
        # Set an environment variable
        os.environ['TEST_INT_VALUE'] = '42'
        
        value = config.get_int('test.int.value', default=0)
        assert isinstance(value, int)
        
        # Clean up
        del os.environ['TEST_INT_VALUE']
        
    except ImportError:
        pytest.skip("Config module not in path")


def test_config_get_bool():
    """Test config.get_bool() method."""
    try:
        from src.config import config
        
        # Test various boolean values
        test_cases = [
            ('true', True),
            ('True', True),
            ('1', True),
            ('yes', True),
            ('false', False),
            ('False', False),
            ('0', False),
            ('no', False)
        ]
        
        for str_val, expected in test_cases:
            os.environ['TEST_BOOL_VALUE'] = str_val
            value = config.get_bool('test.bool.value', default=False)
            assert value == expected, f"Failed for {str_val}"
        
        # Clean up
        if 'TEST_BOOL_VALUE' in os.environ:
            del os.environ['TEST_BOOL_VALUE']
        
    except ImportError:
        pytest.skip("Config module not in path")


def test_config_get_path():
    """Test config.get_path() method."""
    try:
        from src.config import config
        
        path = config.get_path('paths.models', default='models')
        assert isinstance(path, Path)
        
    except ImportError:
        pytest.skip("Config module not in path")


def test_convenience_functions():
    """Test convenience functions."""
    try:
        from src.config import (
            get_api_host,
            get_api_port,
            get_model_dir,
            get_log_level
        )
        
        # Just check they don't raise exceptions
        host = get_api_host()
        assert isinstance(host, str)
        
        port = get_api_port()
        assert isinstance(port, int)
        
        model_dir = get_model_dir()
        assert isinstance(model_dir, Path)
        
        log_level = get_log_level()
        assert isinstance(log_level, str)
        
    except ImportError:
        pytest.skip("Config module not in path")


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
