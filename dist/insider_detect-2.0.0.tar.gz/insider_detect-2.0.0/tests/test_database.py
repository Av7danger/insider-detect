"""
Unit tests for database operations.

Run with: pytest tests/test_database.py -v
"""

import pytest
from datetime import datetime


@pytest.fixture
def test_db():
    """Create a test database."""
    try:
        from src.database import init_db
        
        # Use in-memory SQLite for testing
        engine = init_db('sqlite:///:memory:', echo=False)
        yield engine
    except ImportError:
        pytest.skip("Database module not available")


def test_database_init(test_db):
    """Test database initialization."""
    assert test_db is not None


def test_store_prediction():
    """Test storing a prediction."""
    try:
        from src.database import init_db, store_prediction
        
        # Initialize in-memory database
        init_db('sqlite:///:memory:', echo=False)
        
        # Store a test prediction
        pred = store_prediction(
            session_id='test_session_001',
            user='testuser',
            hybrid_prob=0.75,
            prediction=1,
            xgb_prob=0.70,
            lstm_prob=0.80,
            num_events=50,
            duration_seconds=300.0,
            alert=True
        )
        
        assert pred is not None
        assert pred.session_id == 'test_session_001'
        assert pred.user == 'testuser'
        assert pred.hybrid_prob == 0.75
        assert pred.prediction == 1
        assert pred.alert is True
        
    except ImportError:
        pytest.skip("Database module not available")


def test_get_statistics():
    """Test getting statistics."""
    try:
        from src.database import init_db, store_prediction, get_statistics
        
        # Initialize in-memory database
        init_db('sqlite:///:memory:', echo=False)
        
        # Store some test predictions
        store_prediction(
            session_id='test_001',
            user='user1',
            hybrid_prob=0.3,
            prediction=0,
            alert=False
        )
        
        store_prediction(
            session_id='test_002',
            user='user2',
            hybrid_prob=0.8,
            prediction=1,
            alert=True
        )
        
        stats = get_statistics()
        
        assert stats['total_predictions'] == 2
        assert stats['total_alerts'] == 1
        assert stats['alert_rate'] == 0.5
        
    except ImportError:
        pytest.skip("Database module not available")


def test_session_prediction_to_dict():
    """Test SessionPrediction.to_dict() method."""
    try:
        from src.database import SessionPrediction
        
        pred = SessionPrediction(
            session_id='test',
            user='user',
            hybrid_prob=0.5,
            prediction=0
        )
        
        pred_dict = pred.to_dict()
        
        assert isinstance(pred_dict, dict)
        assert 'session_id' in pred_dict
        assert 'user' in pred_dict
        assert 'hybrid_prob' in pred_dict
        
    except ImportError:
        pytest.skip("Database module not available")


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
