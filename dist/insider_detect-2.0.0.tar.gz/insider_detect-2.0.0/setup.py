"""
Setup configuration for Insider Threat Detection System.

Install in development mode:
    pip install -e .

Install normally:
    pip install .
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

# Read requirements
requirements = (this_directory / "requirements.txt").read_text().strip().split('\n')
dev_requirements = (this_directory / "requirements-dev.txt").read_text().strip().split('\n')

setup(
    name="insider-detect",
    version="2.0.0",
    author="Insider Threat Detection Team",
    description="ML-based insider threat detection system",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Av7danger/insider-detect",
    packages=find_packages(exclude=["tests", "tests.*", "docs", "scripts"]),
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=requirements,
    extras_require={
        "dev": dev_requirements,
    },
    entry_points={
        "console_scripts": [
            "insider-detect=app.api:main",
            "insider-train=training.train:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
