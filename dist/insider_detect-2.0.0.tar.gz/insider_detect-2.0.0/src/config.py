"""
Test-facing wrapper for configuration utilities.

Provides `from src.config import Config, config` and convenience getters by
delegating to `app.core.config`.
"""

from app.core.config import *  # noqa: F401,F403


