"""
Hybrid ensemble model combining XGBoost and LSTM predictions.

This module provides inference capabilities using both models and
combines their predictions for improved accuracy.
"""

import pandas as pd
import numpy as np
import joblib
import os
from tensorflow import keras
from tensorflow.keras.preprocessing.sequence import pad_sequences
import warnings
warnings.filterwarnings('ignore')

# Import feature preparation
from app.utils.features import build_features


class HybridModel:
    """
    Hybrid ensemble model combining XGBoost and LSTM.
    """
    
    def __init__(self, model_dir='models'):
        """
        Initialize hybrid model by loading XGBoost and LSTM artifacts.
        
        Args:
            model_dir (str): Directory containing model files
        """
        self.model_dir = model_dir
        
        # Load XGBoost artifacts
        print("Loading XGBoost model...")
        self.xgb_model = joblib.load(os.path.join(model_dir, 'xgb_model.pkl'))
        self.xgb_scaler = joblib.load(os.path.join(model_dir, 'xgb_scaler.pkl'))
        self.xgb_le_user = joblib.load(os.path.join(model_dir, 'xgb_le.pkl'))
        print("✅ XGBoost model loaded")
        
        # Load LSTM artifacts
        print("Loading LSTM model...")
        self.lstm_model = keras.models.load_model(os.path.join(model_dir, 'lstm_model.h5'))
        self.action_vocab = joblib.load(os.path.join(model_dir, 'action_vocab.pkl'))
        self.lstm_metadata = joblib.load(os.path.join(model_dir, 'lstm_metadata.pkl'))
        self.max_len = self.lstm_metadata['max_len']
        print("✅ LSTM model loaded")
        
        # Ensemble weights
        self.xgb_weight = 0.6
        self.lstm_weight = 0.4
        
        print(f"\nHybrid model initialized:")
        print(f"  XGBoost weight: {self.xgb_weight}")
        print(f"  LSTM weight: {self.lstm_weight}")
    
    def _prepare_xgb_features(self, session_df):
        """
        Prepare features for XGBoost model.
        
        Args:
            session_df (pd.DataFrame): Session-level features
        
        Returns:
            np.ndarray: Prepared feature matrix
        """
        # Pass pre-fitted user label encoder if available in artifacts
        try:
            from sklearn.preprocessing import LabelEncoder  # type: ignore
            le_user = joblib.load(os.path.join(self.model_dir, 'xgb_le.pkl'))
        except Exception:
            le_user = None

        X, _, _, _, _ = build_features(
            session_df,
            fit=False,
            scaler=self.xgb_scaler,
            vect=None,
            user_stats=None,
            le_user=le_user,
        )
        return X
    
    def _prepare_lstm_sequence(self, session_events_list):
        """
        Prepare action sequence for LSTM model.
        
        Args:
            session_events_list (list): List of action strings
        
        Returns:
            np.ndarray: Padded sequence of action IDs
        """
        # Encode actions
        sequence = []
        for action in session_events_list:
            action_id = self.action_vocab.get(action, self.action_vocab.get('<UNK>', 1))
            sequence.append(action_id)
        
        # Pad sequence
        padded = pad_sequences(
            [sequence],
            maxlen=self.max_len,
            padding='post',
            truncating='post',
            value=self.action_vocab.get('<PAD>', 0)
        )
        
        return padded
    
    def infer_session(self, session_events_list, session_features=None):
        """
        Infer malicious probability for a session using hybrid ensemble.
        
        Args:
            session_events_list (list): List of action strings in the session
            session_features (dict, optional): Session-level features for XGBoost
                Required keys: duration_s, num_events, unique_actions, 
                              unique_src_ips, file_actions_ratio, user
        
        Returns:
            dict: Dictionary containing:
                - prob_xgb: XGBoost probability
                - prob_lstm: LSTM probability
                - hybrid_prob: Weighted ensemble probability
                - prediction: Binary prediction (0=normal, 1=malicious)
        """
        # Get LSTM prediction
        lstm_sequence = self._prepare_lstm_sequence(session_events_list)
        prob_lstm = float(self.lstm_model.predict(lstm_sequence, verbose=0)[0][0])
        
        # Get XGBoost prediction if features provided
        if session_features is not None:
            # Create DataFrame from features
            session_df = pd.DataFrame([session_features])
            xgb_features = self._prepare_xgb_features(session_df)
            prob_xgb = float(self.xgb_model.predict_proba(xgb_features)[0][1])
        else:
            # Use only LSTM if no features provided
            prob_xgb = None
        
        # Calculate hybrid probability
        if prob_xgb is not None:
            hybrid_prob = self.xgb_weight * prob_xgb + self.lstm_weight * prob_lstm
        else:
            hybrid_prob = prob_lstm
        
        # Make binary prediction
        prediction = 1 if hybrid_prob > 0.5 else 0
        
        return {
            'prob_xgb': prob_xgb,
            'prob_lstm': prob_lstm,
            'hybrid_prob': hybrid_prob,
            'prediction': prediction,
            'prediction_label': 'malicious' if prediction == 1 else 'normal'
        }
    
    def batch_infer(self, sessions_data):
        """
        Perform batch inference on multiple sessions.
        
        Args:
            sessions_data (list): List of tuples (session_events_list, session_features)
        
        Returns:
            list: List of prediction dictionaries
        """
        results = []
        for session_events, session_features in sessions_data:
            result = self.infer_session(session_events, session_features)
            results.append(result)
        return results


def load_hybrid_model(model_dir='models'):
    """
    Load and return hybrid model instance.
    
    Args:
        model_dir (str): Directory containing model files
    
    Returns:
        HybridModel: Initialized hybrid model
    """
    return HybridModel(model_dir)


def infer_session(session_events_list, session_features=None, model_dir='models'):
    """
    Standalone inference function for a single session.
    
    Args:
        session_events_list (list): List of action strings
        session_features (dict, optional): Session-level features
        model_dir (str): Directory containing model files
    
    Returns:
        dict: Prediction results
    """
    model = HybridModel(model_dir)
    return model.infer_session(session_events_list, session_features)


def main():
    """Demo of hybrid model inference."""
    print("=" * 60)
    print("Hybrid Model Demo")
    print("=" * 60)
    
    # Load model
    model = HybridModel(model_dir='models')
    
    # Example benign session
    print("\n1. Benign Session Example:")
    benign_actions = ['login', 'file_access', 'file_access', 'logout']
    benign_features = {
        'duration_s': 300,
        'num_events': 4,
        'unique_actions': 3,
        'unique_src_ips': 1,
        'file_actions_ratio': 0.5,
        'user': 'user001'
    }
    
    result = model.infer_session(benign_actions, benign_features)
    print(f"Actions: {benign_actions}")
    print(f"XGBoost prob: {result['prob_xgb']:.4f}")
    print(f"LSTM prob: {result['prob_lstm']:.4f}")
    print(f"Hybrid prob: {result['hybrid_prob']:.4f}")
    print(f"Prediction: {result['prediction_label']}")
    
    # Example suspicious session
    print("\n2. Suspicious Session Example:")
    suspicious_actions = ['login', 'file_access', 'file_copy', 'file_share', 'file_download', 'logout']
    suspicious_features = {
        'duration_s': 600,
        'num_events': 6,
        'unique_actions': 5,
        'unique_src_ips': 2,
        'file_actions_ratio': 0.83,
        'user': 'user003'
    }
    
    result = model.infer_session(suspicious_actions, suspicious_features)
    print(f"Actions: {suspicious_actions}")
    print(f"XGBoost prob: {result['prob_xgb']:.4f}")
    print(f"LSTM prob: {result['prob_lstm']:.4f}")
    print(f"Hybrid prob: {result['hybrid_prob']:.4f}")
    print(f"Prediction: {result['prediction_label']}")
    
    print("\n" + "=" * 60)


if __name__ == '__main__':
    main()
