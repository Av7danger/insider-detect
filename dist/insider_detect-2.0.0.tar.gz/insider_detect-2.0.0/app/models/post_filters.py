"""
Post-processing filters for reducing false positives in insider threat detection.

This module implements rule-based filters to suppress alerts for known-safe
scenarios, reducing analyst workload while maintaining high detection rates.
"""

import pandas as pd
from datetime import datetime, time
from typing import Dict, List, Optional, Tuple
import ipaddress
import json
import os


class PostFilters:
    """
    Post-processing filters for suppressing false positive alerts.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize post-filters with configuration.
        
        Args:
            config_path (str, optional): Path to filter configuration JSON
        """
        # Default whitelists
        self.trusted_ips = [
            '192.168.1.100',  # Admin workstation
            '10.0.0.10',      # IT department gateway
            '10.0.1.50',      # Backup server
        ]
        
        self.trusted_users = [
            'system',
            'admin',
            'backup_service',
            'monitoring_agent'
        ]
        
        self.safe_actions = [
            'login',
            'logout',
            'auth_success',
            'auth_failure',
            'heartbeat',
            'status_check'
        ]
        
        # Scheduled backup windows (hour ranges in 24h format)
        self.backup_windows = [
            (time(0, 0), time(4, 0)),   # Midnight to 4 AM
            (time(22, 0), time(23, 59))  # 10 PM to midnight
        ]
        
        # Business hours (when normal activity is expected)
        self.business_hours = (time(8, 0), time(18, 0))
        
        # Thresholds
        self.max_safe_file_ratio = 0.3  # Max file action ratio for safe sessions
        self.max_safe_duration = 300     # Max duration (seconds) for quick safe sessions
        
        # Load custom configuration if provided
        if config_path and os.path.exists(config_path):
            self.load_config(config_path)
    
    def load_config(self, config_path: str):
        """
        Load filter configuration from JSON file.
        
        Args:
            config_path (str): Path to configuration file
        """
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        if 'trusted_ips' in config:
            self.trusted_ips.extend(config['trusted_ips'])
        
        if 'trusted_users' in config:
            self.trusted_users.extend(config['trusted_users'])
        
        if 'safe_actions' in config:
            self.safe_actions.extend(config['safe_actions'])
    
    def is_trusted_ip(self, ip: str) -> bool:
        """
        Check if IP address is in trusted whitelist.
        
        Args:
            ip (str): IP address to check
        
        Returns:
            bool: True if IP is trusted
        """
        return ip in self.trusted_ips
    
    def is_trusted_user(self, user: str) -> bool:
        """
        Check if user is in trusted whitelist.
        
        Args:
            user (str): Username to check
        
        Returns:
            bool: True if user is trusted
        """
        return user.lower() in [u.lower() for u in self.trusted_users]
    
    def is_backup_window(self, timestamp: datetime) -> bool:
        """
        Check if timestamp falls within scheduled backup window.
        
        Args:
            timestamp (datetime): Timestamp to check
        
        Returns:
            bool: True if within backup window
        """
        t = timestamp.time()
        for start, end in self.backup_windows:
            if start <= t <= end:
                return True
        return False
    
    def is_business_hours(self, timestamp: datetime) -> bool:
        """
        Check if timestamp falls within business hours.
        
        Args:
            timestamp (datetime): Timestamp to check
        
        Returns:
            bool: True if within business hours
        """
        t = timestamp.time()
        return self.business_hours[0] <= t <= self.business_hours[1]
    
    def is_safe_action_pattern(self, actions: List[str]) -> bool:
        """
        Check if action sequence contains only safe actions.
        
        Args:
            actions (list): List of action strings
        
        Returns:
            bool: True if all actions are safe
        """
        return all(action in self.safe_actions for action in actions)
    
    def is_quick_session(self, duration_s: float) -> bool:
        """
        Check if session duration is very short (likely automated).
        
        Args:
            duration_s (float): Session duration in seconds
        
        Returns:
            bool: True if session is quick
        """
        return duration_s <= self.max_safe_duration
    
    def is_low_file_activity(self, file_actions_ratio: float) -> bool:
        """
        Check if file action ratio is low (normal behavior).
        
        Args:
            file_actions_ratio (float): Ratio of file actions to total actions
        
        Returns:
            bool: True if file activity is low
        """
        return file_actions_ratio <= self.max_safe_file_ratio
    
    def apply_filters(self, session_dict: Dict) -> Tuple[bool, List[str]]:
        """
        Apply all filters to a session and determine if alert should be suppressed.
        
        Args:
            session_dict (dict): Session data with keys:
                - user: username
                - src_ips: list of source IPs or single IP
                - actions: list of action strings
                - timestamp: session start timestamp (datetime or string)
                - duration_s: session duration in seconds
                - file_actions_ratio: ratio of file actions
                - hybrid_prob: hybrid model probability (optional)
        
        Returns:
            tuple: (suppressed: bool, reasons: List[str])
                - suppressed: True if alert should be suppressed
                - reasons: List of filter rules that matched
        """
        reasons = []
        
        # Extract session data
        user = session_dict.get('user', '')
        src_ips = session_dict.get('src_ips', [])
        if isinstance(src_ips, str):
            src_ips = [src_ips]
        
        actions = session_dict.get('actions', [])
        duration_s = session_dict.get('duration_s', 0)
        file_actions_ratio = session_dict.get('file_actions_ratio', 0.0)
        
        # Parse timestamp if it's a string
        timestamp = session_dict.get('timestamp')
        if isinstance(timestamp, str):
            try:
                timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            except:
                timestamp = None
        
        # Rule 1: Trusted user
        if self.is_trusted_user(user):
            reasons.append(f"Trusted user: {user}")
        
        # Rule 2: All IPs are trusted
        if src_ips and all(self.is_trusted_ip(ip) for ip in src_ips):
            reasons.append(f"All IPs trusted: {src_ips}")
        
        # Rule 3: Backup window with high file activity
        if timestamp and self.is_backup_window(timestamp):
            reasons.append(f"Backup window: {timestamp.strftime('%H:%M')}")
        
        # Rule 4: Safe action pattern only
        if actions and self.is_safe_action_pattern(actions):
            reasons.append(f"Safe actions only: {set(actions)}")
        
        # Rule 5: Quick session with low file activity during business hours
        if (timestamp and 
            self.is_business_hours(timestamp) and 
            self.is_quick_session(duration_s) and 
            self.is_low_file_activity(file_actions_ratio)):
            reasons.append(
                f"Quick safe session during business hours "
                f"({duration_s}s, file_ratio={file_actions_ratio:.2f})"
            )
        
        # Decision: suppress if any filter matched
        suppressed = len(reasons) > 0
        
        return suppressed, reasons
    
    def filter_dataframe(self, df: pd.DataFrame, prob_column: str = 'hybrid_prob') -> pd.DataFrame:
        """
        Apply filters to a DataFrame of sessions.
        
        Args:
            df (pd.DataFrame): DataFrame with session data
            prob_column (str): Column name containing probability scores
        
        Returns:
            pd.DataFrame: Filtered DataFrame with added columns:
                - suppressed: bool indicating if alert is suppressed
                - filter_reasons: string with suppression reasons
        """
        results = []
        
        for idx, row in df.iterrows():
            session_dict = row.to_dict()
            suppressed, reasons = self.apply_filters(session_dict)
            
            results.append({
                'suppressed': suppressed,
                'filter_reasons': '; '.join(reasons) if reasons else ''
            })
        
        result_df = pd.DataFrame(results, index=df.index)
        return pd.concat([df, result_df], axis=1)


def apply_filters(session_dict: Dict, config_path: Optional[str] = None) -> bool:
    """
    Standalone function to apply filters to a single session.
    
    Args:
        session_dict (dict): Session data
        config_path (str, optional): Path to filter configuration
    
    Returns:
        bool: True if alert should be suppressed
    """
    filters = PostFilters(config_path=config_path)
    suppressed, _ = filters.apply_filters(session_dict)
    return suppressed


def main():
    """
    Demo of post-filtering on example sessions.
    """
    print("=" * 70)
    print("Post-Processing Filters Demo")
    print("=" * 70)
    
    filters = PostFilters()
    
    # Example 1: Trusted user session
    print("\nExample 1: Trusted User Session")
    print("-" * 70)
    session1 = {
        'user': 'admin',
        'src_ips': ['192.168.1.100'],
        'actions': ['login', 'file_access', 'file_write', 'logout'],
        'timestamp': '2024-01-15T14:30:00',
        'duration_s': 600,
        'file_actions_ratio': 0.5,
        'hybrid_prob': 0.45
    }
    
    suppressed, reasons = filters.apply_filters(session1)
    print(f"User: {session1['user']}")
    print(f"Actions: {session1['actions']}")
    print(f"Hybrid Probability: {session1['hybrid_prob']:.3f}")
    print(f"\nSuppressed: {suppressed}")
    if reasons:
        print(f"Reasons:")
        for reason in reasons:
            print(f"  - {reason}")
    
    # Example 2: Backup window session
    print("\n\nExample 2: Backup Window Session")
    print("-" * 70)
    session2 = {
        'user': 'user001',
        'src_ips': ['10.0.1.50'],
        'actions': ['login', 'file_read', 'file_copy', 'file_copy', 'logout'],
        'timestamp': '2024-01-15T02:00:00',  # 2 AM - backup window
        'duration_s': 1800,
        'file_actions_ratio': 0.8,
        'hybrid_prob': 0.55
    }
    
    suppressed, reasons = filters.apply_filters(session2)
    print(f"User: {session2['user']}")
    print(f"Timestamp: {session2['timestamp']}")
    print(f"Actions: {session2['actions']}")
    print(f"File Ratio: {session2['file_actions_ratio']:.2f}")
    print(f"Hybrid Probability: {session2['hybrid_prob']:.3f}")
    print(f"\nSuppressed: {suppressed}")
    if reasons:
        print(f"Reasons:")
        for reason in reasons:
            print(f"  - {reason}")
    
    # Example 3: Quick safe session during business hours
    print("\n\nExample 3: Quick Safe Session (Business Hours)")
    print("-" * 70)
    session3 = {
        'user': 'user002',
        'src_ips': ['192.168.1.105'],
        'actions': ['login', 'file_access', 'logout'],
        'timestamp': '2024-01-15T10:30:00',  # 10:30 AM
        'duration_s': 180,  # 3 minutes
        'file_actions_ratio': 0.25,
        'hybrid_prob': 0.35
    }
    
    suppressed, reasons = filters.apply_filters(session3)
    print(f"User: {session3['user']}")
    print(f"Timestamp: {session3['timestamp']}")
    print(f"Duration: {session3['duration_s']}s")
    print(f"File Ratio: {session3['file_actions_ratio']:.2f}")
    print(f"Hybrid Probability: {session3['hybrid_prob']:.3f}")
    print(f"\nSuppressed: {suppressed}")
    if reasons:
        print(f"Reasons:")
        for reason in reasons:
            print(f"  - {reason}")
    
    # Example 4: Suspicious session (not suppressed)
    print("\n\nExample 4: Suspicious Session (NOT Suppressed)")
    print("-" * 70)
    session4 = {
        'user': 'user003',
        'src_ips': ['10.0.50.20', '10.0.60.30'],  # Multiple IPs
        'actions': ['login', 'file_access', 'file_copy', 'file_share', 
                   'file_download', 'logout'],
        'timestamp': '2024-01-15T15:00:00',  # 3 PM
        'duration_s': 900,  # 15 minutes
        'file_actions_ratio': 0.85,
        'hybrid_prob': 0.65
    }
    
    suppressed, reasons = filters.apply_filters(session4)
    print(f"User: {session4['user']}")
    print(f"Source IPs: {session4['src_ips']}")
    print(f"Actions: {session4['actions']}")
    print(f"Duration: {session4['duration_s']}s")
    print(f"File Ratio: {session4['file_actions_ratio']:.2f}")
    print(f"Hybrid Probability: {session4['hybrid_prob']:.3f}")
    print(f"\nSuppressed: {suppressed}")
    if reasons:
        print(f"Reasons:")
        for reason in reasons:
            print(f"  - {reason}")
    else:
        print("No filter rules matched - alert would be triggered!")
    
    print("\n" + "=" * 70)
    print("Filter Statistics:")
    print("-" * 70)
    print(f"Trusted IPs: {len(filters.trusted_ips)}")
    print(f"Trusted Users: {len(filters.trusted_users)}")
    print(f"Safe Actions: {len(filters.safe_actions)}")
    print(f"Backup Windows: {len(filters.backup_windows)}")
    print(f"Business Hours: {filters.business_hours[0]} - {filters.business_hours[1]}")
    print("=" * 70)


if __name__ == '__main__':
    main()
