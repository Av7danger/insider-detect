"""
Model version management for Insider Threat Detection System.

This module provides:
- Model versioning and directory management
- Loading specific model versions
- Model rollback capability
- Version metadata tracking

Directory structure:
    models/
        v1/
            xgb_model.pkl
            lstm_model.h5
            metadata.json
        v2/
            xgb_model.pkl
            lstm_model.h5
            metadata.json
        current -> v2/  (symlink)

Usage:
    from model_manager import ModelManager
    
    manager = ModelManager('models')
    
    # Load current version
    model = manager.load_model()
    
    # Load specific version
    model = manager.load_model('v1')
    
    # List available versions
    versions = manager.list_versions()
    
    # Set current version
    manager.set_current('v2')
"""

import json
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime

try:
    from app.models.hybrid import HybridModel
    from app.core.logging import setup_logging
except ImportError:
    from hybrid import HybridModel
    from logging_config import setup_logging

logger = setup_logging('model_manager')


class ModelManager:
    """
    Manage multiple versions of ML models.
    """
    
    def __init__(self, base_dir: str = 'models'):
        """
        Initialize model manager.
        
        Args:
            base_dir: Base directory containing model versions
        """
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info("Model manager initialized with base_dir: %s", self.base_dir)
    
    def list_versions(self) -> List[str]:
        """
        List all available model versions.
        
        Returns:
            List of version names (e.g., ['v1', 'v2'])
        """
        versions = []
        
        for path in self.base_dir.iterdir():
            if path.is_dir() and not path.name.startswith('.'):
                # Check if it's a valid model directory
                if (path / 'xgb_model.pkl').exists() or (path / 'xgb_model_v3.pkl').exists():
                    versions.append(path.name)
        
        versions.sort()
        logger.debug("Found %d model versions: %s", len(versions), versions)
        return versions
    
    def get_current_version(self) -> Optional[str]:
        """
        Get the current active model version.
        
        Returns:
            Version name or None if no current version set
        """
        current_link = self.base_dir / 'current'
        
        if current_link.is_symlink():
            target = current_link.resolve()
            return target.name
        
        # If no symlink, try to find latest version
        versions = self.list_versions()
        if versions:
            return versions[-1]  # Return latest version
        
        return None
    
    def set_current(self, version: str) -> bool:
        """
        Set the current active model version.
        
        Args:
            version: Version name to set as current
            
        Returns:
            True if successful, False otherwise
        """
        version_path = self.base_dir / version
        
        if not version_path.exists():
            logger.error("Version %s does not exist", version)
            return False
        
        current_link = self.base_dir / 'current'
        
        try:
            # Remove existing symlink if it exists
            if current_link.exists() or current_link.is_symlink():
                current_link.unlink()
            
            # Create new symlink
            # Note: On Windows, this may require admin privileges
            # Alternative: create a text file with version name
            try:
                current_link.symlink_to(version, target_is_directory=True)
                logger.info("Set current version to: %s", version)
            except OSError:
                # Fallback: create a text file
                with open(current_link, 'w') as f:
                    f.write(version)
                logger.info("Set current version to: %s (using text file)", version)
            
            return True
        
        except Exception as e:
            logger.error("Failed to set current version: %s", str(e))
            return False
    
    def load_model(self, version: Optional[str] = None) -> HybridModel:
        """
        Load a specific model version.
        
        Args:
            version: Version to load (None = current version)
            
        Returns:
            Loaded HybridModel instance
            
        Raises:
            ValueError: If version not found
            RuntimeError: If model loading fails
        """
        if version is None:
            version = self.get_current_version()
            
            if version is None:
                # No version specified and no current - use base directory
                logger.warning("No version specified, loading from base directory")
                return HybridModel(model_dir=str(self.base_dir))
        
        model_dir = self.base_dir / version
        
        if not model_dir.exists():
            raise ValueError(f"Model version {version} not found at {model_dir}")
        
        logger.info("Loading model version: %s", version)
        
        try:
            model = HybridModel(model_dir=str(model_dir))
            logger.info("Successfully loaded model version: %s", version)
            return model
        except Exception as e:
            logger.error("Failed to load model version %s: %s", version, str(e))
            raise RuntimeError(f"Failed to load model: {str(e)}")
    
    def get_version_metadata(self, version: str) -> Optional[Dict[str, Any]]:
        """
        Get metadata for a specific version.
        
        Args:
            version: Version name
            
        Returns:
            Metadata dictionary or None if not found
        """
        metadata_path = self.base_dir / version / 'metadata.json'
        
        if not metadata_path.exists():
            # Try alternate names
            alt_paths = [
                self.base_dir / version / 'xgb_v3_metrics.json',
                self.base_dir / version / 'lstm_metadata.pkl',
            ]
            
            for alt_path in alt_paths:
                if alt_path.exists():
                    try:
                        with open(alt_path) as f:
                            return json.load(f)
                    except:
                        pass
            
            logger.warning("No metadata found for version: %s", version)
            return None
        
        try:
            with open(metadata_path) as f:
                metadata = json.load(f)
            return metadata
        except Exception as e:
            logger.error("Failed to load metadata for %s: %s", version, str(e))
            return None
    
    def save_version_metadata(
        self,
        version: str,
        metadata: Dict[str, Any]
    ) -> bool:
        """
        Save metadata for a specific version.
        
        Args:
            version: Version name
            metadata: Metadata dictionary
            
        Returns:
            True if successful, False otherwise
        """
        version_path = self.base_dir / version
        version_path.mkdir(parents=True, exist_ok=True)
        
        metadata_path = version_path / 'metadata.json'
        
        try:
            # Add timestamp
            metadata['saved_at'] = datetime.now().isoformat()
            
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            
            logger.info("Saved metadata for version: %s", version)
            return True
        
        except Exception as e:
            logger.error("Failed to save metadata: %s", str(e))
            return False
    
    def create_new_version(self, name: Optional[str] = None) -> str:
        """
        Create a new version directory.
        
        Args:
            name: Version name (auto-generated if None)
            
        Returns:
            Created version name
        """
        if name is None:
            # Auto-generate version name
            existing = self.list_versions()
            if not existing:
                name = 'v1'
            else:
                # Extract numbers and increment
                numbers = []
                for v in existing:
                    if v.startswith('v') and v[1:].isdigit():
                        numbers.append(int(v[1:]))
                
                if numbers:
                    name = f'v{max(numbers) + 1}'
                else:
                    name = f'v{len(existing) + 1}'
        
        version_path = self.base_dir / name
        version_path.mkdir(parents=True, exist_ok=True)
        
        logger.info("Created new version: %s", name)
        return name
    
    def compare_versions(self, v1: str, v2: str) -> Dict[str, Any]:
        """
        Compare two model versions.
        
        Args:
            v1: First version name
            v2: Second version name
            
        Returns:
            Comparison results
        """
        meta1 = self.get_version_metadata(v1)
        meta2 = self.get_version_metadata(v2)
        
        comparison = {
            'version_1': v1,
            'version_2': v2,
            'metadata_1': meta1,
            'metadata_2': meta2
        }
        
        # Compare metrics if available
        if meta1 and meta2:
            if 'accuracy' in meta1 and 'accuracy' in meta2:
                comparison['accuracy_diff'] = meta2['accuracy'] - meta1['accuracy']
            
            if 'f1_score' in meta1 and 'f1_score' in meta2:
                comparison['f1_diff'] = meta2['f1_score'] - meta1['f1_score']
        
        return comparison


if __name__ == '__main__':
    # Test model manager
    manager = ModelManager('models')
    
    print("Available versions:", manager.list_versions())
    print("Current version:", manager.get_current_version())
    
    # Try to load current model
    try:
        model = manager.load_model()
        print("✅ Model loaded successfully")
    except Exception as e:
        print(f"❌ Failed to load model: {e}")
