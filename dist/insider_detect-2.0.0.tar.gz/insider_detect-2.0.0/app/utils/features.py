# src/feature_engineering_v2.py
"""
Feature engineering v2 for session-level data.
Produces numeric features + sparse action-ngram features + user-baseline deviation features.

Functions:
- build_features(sessions_df, fit=True, scaler=None, vect=None, user_stats=None)
    returns (X, feature_names, scaler, vect, user_stats)
- save_artifacts(path_dict)
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.feature_extraction.text import CountVectorizer
from scipy import sparse
import joblib
from collections import Counter
from math import log2

def _session_action_text(df):
    # join actions into a single string per session (space-separated)
    return df['actions_joined'].fillna("").astype(str)

def _safe_div(a, b):
    return a / (b + 1e-9)

def action_entropy(action_list):
    if len(action_list)==0:
        return 0.0
    c = Counter(action_list)
    total = sum(c.values())
    ent = -sum((v/total) * np.log2(v/total) for v in c.values())
    return float(ent)

def compute_user_stats(sessions_df):
    # compute per-user historical mean/std for selected numeric features
    grp = sessions_df.groupby('user')
    stats = {}
    num_cols = ['duration_s','num_events','file_actions_ratio']
    for user, g in grp:
        stats[user] = {}
        for c in num_cols:
            stats[user][c+'_mean'] = float(g[c].mean())
            stats[user][c+'_std'] = float(g[c].std() if g[c].std() and not np.isnan(g[c].std()) else 0.0)
    # global fallback
    global_stats = {}
    for c in num_cols:
        global_stats[c+'_mean'] = float(sessions_df[c].mean())
        global_stats[c+'_std'] = float(sessions_df[c].std() if sessions_df[c].std() and not np.isnan(sessions_df[c].std()) else 0.0)
    return {'per_user': stats, 'global': global_stats}

def apply_user_deviation(row, user_stats):
    user = row['user']
    out = {}
    for c in ['duration_s','num_events','file_actions_ratio']:
        gm = user_stats['global'][c+'_mean']
        gs = user_stats['global'][c+'_std'] if user_stats['global'][c+'_std']>0 else 1.0
        if user in user_stats['per_user']:
            um = user_stats['per_user'][user].get(c+'_mean', gm)
            us = user_stats['per_user'][user].get(c+'_std', gs) or gs
        else:
            um, us = gm, gs
        # deviation (z-score)
        out[c+'_z'] = (row[c] - um) / (us + 1e-9)
        # absolute difference normalized by global mean
        out[c+'_abs_diff_norm'] = _safe_div(abs(row[c] - um), (gm + 1e-9))
    return out

def build_features(
    sessions_df,
    fit=True,
    scaler=None,
    vect=None,
    user_stats=None,
    max_ngram_features=200,
    le_user=None,
):
    """
    sessions_df must contain:
    - global_session_id, user, start_ts, end_ts, duration_s, num_events, unique_actions,
      unique_src_ips, file_actions_ratio, actions_list (iterable) OR actions_joined string

    If fit=True: fit scaler, vect, compute user_stats from sessions_df.
    Returns:
      X (sparse or dense matrix), feature_names (list), scaler, vect, user_stats
    """
    df = sessions_df.copy()

    # --- ensure fields exist
    # If actions_list present, create joined string
    if 'actions_list' in df.columns:
        df['actions_joined'] = df['actions_list'].apply(lambda lst: " ".join([str(x).replace(" ", "_") for x in lst]) if isinstance(lst, (list, tuple)) else str(lst))
    else:
        df['actions_joined'] = df.get('actions_joined', "")

    # Parse timestamps if needed
    if 'start_ts' in df.columns:
        df['start_ts'] = pd.to_datetime(df['start_ts'])
    else:
        df['start_ts'] = pd.to_datetime(df.get('timestamp', pd.NaT))

    # --- temporal features
    df['hour'] = df['start_ts'].dt.hour.fillna(0).astype(int)
    df['is_weekend'] = df['start_ts'].dt.weekday.isin([5,6]).astype(int)
    df['dayofweek'] = df['start_ts'].dt.weekday.fillna(0).astype(int)

    # --- velocity/time-based features
    df['events_per_min'] = df['num_events'] / ( (df['duration_s'] / 60.0) + 1e-9 )
    df['avg_event_delta_s'] = df['duration_s'] / (df['num_events'] + 1e-9)

    # --- action entropy (diversity inside session)
    if 'actions_list' in df.columns:
        df['action_entropy'] = df['actions_list'].apply(lambda x: action_entropy(x if isinstance(x, (list,tuple)) else []))
    else:
        # fallback: estimate by splitting joined actions
        df['action_entropy'] = df['actions_joined'].apply(lambda s: action_entropy(s.split()) if isinstance(s,str) else 0.0)

    # --- basic numeric features already present: duration_s, num_events, unique_actions, unique_src_ips, file_actions_ratio
    numeric_cols = ['duration_s','num_events','unique_actions','unique_src_ips','file_actions_ratio',
                    'events_per_min','avg_event_delta_s','action_entropy']

    for c in numeric_cols:
        df[c] = df[c].fillna(0).astype(float)

    # --- user baseline deviation features
    if fit or user_stats is None:
        user_stats = compute_user_stats(df)
    # apply deviations
    devs = df.apply(lambda r: apply_user_deviation(r, user_stats), axis=1, result_type='expand')
    df = pd.concat([df, devs], axis=1)
    deviation_cols = [c for c in df.columns if c.endswith('_z') or c.endswith('_abs_diff_norm')]

    # --- categorical user encoding (simple label encode)
    # Prefer provided pre-fitted label encoder; otherwise fit on the fly
    if le_user is None:
        le_user = LabelEncoder()
        user_enc = le_user.fit_transform(df['user'].astype(str))
    else:
        try:
            user_enc = le_user.transform(df['user'].astype(str))
        except Exception:
            # As a safe fallback in tests, fit if not fitted
            user_enc = le_user.fit_transform(df['user'].astype(str))
    df['user_enc'] = user_enc

    # --- action n-gram vectorizer (CountVectorizer)
    action_text = _session_action_text(df)
    if action_text.str.strip().str.len().sum() == 0:
        # No textual actions provided; use empty text matrix
        X_text = sparse.csr_matrix((len(df), 0))
        text_names = []
    else:
        if fit or vect is None:
            vect = CountVectorizer(token_pattern=r"(?u)\b\w+\b", ngram_range=(1,2), max_features=max_ngram_features)
            X_text = vect.fit_transform(action_text)
        else:
            X_text = vect.transform(action_text)

    # --- assemble dense numeric matrix
    dense_cols_all = ['user_enc'] + numeric_cols + deviation_cols + ['hour','is_weekend','dayofweek']
    # When using a pre-fitted scaler, align the numeric columns to the scaler's expected size
    if not fit and scaler is not None and hasattr(scaler, 'n_features_in_'):
        expected = int(getattr(scaler, 'n_features_in_', len(dense_cols_all)))
        if expected != len(dense_cols_all):
            priority = [
                'user_enc',
                'num_events',
                'file_actions_ratio',
                'events_per_min',
                'avg_event_delta_s',
                'action_entropy',
                'duration_s',
                'unique_actions',
                'unique_src_ips',
                'hour',
                'is_weekend',
                'dayofweek',
            ]
            chosen = []
            for name in priority:
                if name in dense_cols_all and name not in chosen:
                    chosen.append(name)
                if len(chosen) == expected:
                    break
            # Fallback if still short
            if len(chosen) < expected:
                for name in dense_cols_all:
                    if name not in chosen:
                        chosen.append(name)
                    if len(chosen) == expected:
                        break
            dense_cols = chosen
        else:
            dense_cols = dense_cols_all
    else:
        dense_cols = dense_cols_all

    X_num = df[dense_cols].fillna(0).astype(float).values
    # scale numeric features
    if fit or scaler is None:
        scaler = StandardScaler()
        X_num_scaled = scaler.fit_transform(X_num)
    else:
        X_num_scaled = scaler.transform(X_num)

    # combine sparse and dense
    X_sparse = sparse.hstack([sparse.csr_matrix(X_num_scaled), X_text], format='csr')

    # feature names (dense + vectorizer.get_feature_names_out)
    dense_names = dense_cols
    if 'text_names' not in locals():
        try:
            text_names = vect.get_feature_names_out().tolist()
        except Exception:
            text_names = [f"act_{i}" for i in range(X_text.shape[1])]
    feature_names = dense_names + text_names

    return X_sparse, feature_names, scaler, vect, user_stats
