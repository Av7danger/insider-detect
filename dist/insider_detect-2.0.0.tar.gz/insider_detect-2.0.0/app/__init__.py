"""
Insider Threat Detection System - Application Package.

This package contains the main application code for the
insider threat detection system.
"""

__version__ = "2.0.0"
__author__ = "Insider Threat Detection Team"
