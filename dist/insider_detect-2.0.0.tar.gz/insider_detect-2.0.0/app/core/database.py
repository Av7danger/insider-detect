"""
Database models for Insider Threat Detection System.

This module provides:
- SQLAlchemy ORM models for storing predictions
- Database session management
- Helper functions for CRUD operations

Usage:
    from database import Session, SessionPrediction, init_db
    
    # Initialize database
    init_db()
    
    # Store a prediction
    db = Session()
    pred = SessionPrediction(
        session_id='abc123',
        user='user123',
        hybrid_prob=0.75,
        prediction=1
    )
    db.add(pred)
    db.commit()
    db.close()
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any

from sqlalchemy import (
    create_engine, Column, Integer, String, Float,
    DateTime, Boolean, JSON, Index, desc
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session as SQLSession
from sqlalchemy.pool import StaticPool


# Import config
try:
    from app.core.config import get_db_url, get_data_dir
except ImportError:
    def get_db_url():
        return os.getenv('DB_URL', 'sqlite:///data/predictions.db')
    def get_data_dir():
        return Path('data')


Base = declarative_base()


class SessionPrediction(Base):
    """
    Model for storing session predictions.
    
    Tracks all predictions made by the hybrid model including
    component scores, features, and metadata.
    """
    __tablename__ = 'predictions'
    
    # Primary key
    id = Column(Integer, primary_key=True, autoincrement=True)
    
    # Session identifiers
    session_id = Column(String(100), nullable=False, index=True)
    user = Column(String(100), nullable=False, index=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    session_start = Column(DateTime, nullable=True)
    session_end = Column(DateTime, nullable=True)
    
    # Session metadata
    num_events = Column(Integer, nullable=True)
    duration_seconds = Column(Float, nullable=True)
    unique_actions = Column(Integer, nullable=True)
    
    # Model predictions
    xgb_prob = Column(Float, nullable=True)
    lstm_prob = Column(Float, nullable=True)
    hybrid_prob = Column(Float, nullable=False)
    prediction = Column(Integer, nullable=False)  # 0=benign, 1=threat
    
    # Alert status
    alert = Column(Boolean, default=False, index=True)
    suppressed = Column(Boolean, default=False)
    suppression_reason = Column(String(200), nullable=True)
    
    # Features and metadata (JSON)
    session_features = Column(JSON, nullable=True)
    top_actions = Column(JSON, nullable=True)
    
    # Performance metrics
    inference_time_ms = Column(Float, nullable=True)
    model_version = Column(String(50), nullable=True)
    
    # Indexes for common queries
    __table_args__ = (
        Index('idx_user_created', 'user', 'created_at'),
        Index('idx_alert_created', 'alert', 'created_at'),
        Index('idx_user_alert', 'user', 'alert'),
    )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        return {
            'id': self.id,
            'session_id': self.session_id,
            'user': self.user,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'num_events': self.num_events,
            'xgb_prob': self.xgb_prob,
            'lstm_prob': self.lstm_prob,
            'hybrid_prob': self.hybrid_prob,
            'prediction': self.prediction,
            'alert': self.alert,
            'suppressed': self.suppressed,
            'inference_time_ms': self.inference_time_ms
        }


class ModelMetrics(Base):
    """Track model performance metrics over time."""
    __tablename__ = 'model_metrics'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    model_version = Column(String(50), nullable=False, index=True)
    
    # Metrics
    total_predictions = Column(Integer, default=0)
    total_alerts = Column(Integer, default=0)
    avg_inference_time_ms = Column(Float, nullable=True)
    avg_xgb_prob = Column(Float, nullable=True)
    avg_lstm_prob = Column(Float, nullable=True)
    
    # Performance
    alert_rate = Column(Float, nullable=True)
    suppression_rate = Column(Float, nullable=True)


# Database engine and session factory
engine = None
SessionLocal = None


def init_db(db_url: Optional[str] = None, echo: bool = False):
    """
    Initialize database engine and create tables.
    
    Args:
        db_url: Database URL (e.g., 'sqlite:///data/predictions.db')
        echo: Enable SQL query logging
        
    Returns:
        SQLAlchemy engine
    """
    global engine, SessionLocal
    
    if db_url is None:
        db_url = get_db_url()
    
    # Ensure directory exists for SQLite
    if db_url.startswith('sqlite:///'):
        db_path = Path(db_url.replace('sqlite:///', ''))
        db_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Create engine
    # For SQLite, use StaticPool for compatibility with FastAPI
    if 'sqlite' in db_url:
        engine = create_engine(
            db_url,
            connect_args={'check_same_thread': False},
            poolclass=StaticPool,
            echo=echo
        )
    else:
        engine = create_engine(db_url, echo=echo)
    
    # Create tables
    Base.metadata.create_all(bind=engine)
    
    # Create session factory
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    
    return engine


def get_db() -> SQLSession:
    """
    Get database session (for FastAPI dependency injection).
    
    Usage:
        @app.get("/predictions")
        def get_predictions(db: Session = Depends(get_db)):
            return db.query(SessionPrediction).all()
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def store_prediction(
    session_id: str,
    user: str,
    hybrid_prob: float,
    prediction: int,
    xgb_prob: Optional[float] = None,
    lstm_prob: Optional[float] = None,
    num_events: Optional[int] = None,
    duration_seconds: Optional[float] = None,
    alert: bool = False,
    suppressed: bool = False,
    suppression_reason: Optional[str] = None,
    session_features: Optional[Dict] = None,
    inference_time_ms: Optional[float] = None,
    model_version: Optional[str] = None
) -> Optional[SessionPrediction]:
    """
    Store a prediction in the database.
    
    Args:
        session_id: Unique session identifier
        user: Username
        hybrid_prob: Hybrid model probability
        prediction: Binary prediction (0 or 1)
        xgb_prob: XGBoost probability
        lstm_prob: LSTM probability
        num_events: Number of events in session
        duration_seconds: Session duration
        alert: Whether alert was generated
        suppressed: Whether alert was suppressed
        suppression_reason: Reason for suppression
        session_features: Feature dictionary
        inference_time_ms: Inference time in milliseconds
        model_version: Model version string
        
    Returns:
        SessionPrediction object or None if failed
    """
    if SessionLocal is None:
        init_db()
    
    db = SessionLocal()
    try:
        pred = SessionPrediction(
            session_id=session_id,
            user=user,
            hybrid_prob=hybrid_prob,
            prediction=prediction,
            xgb_prob=xgb_prob,
            lstm_prob=lstm_prob,
            num_events=num_events,
            duration_seconds=duration_seconds,
            alert=alert,
            suppressed=suppressed,
            suppression_reason=suppression_reason,
            session_features=session_features,
            inference_time_ms=inference_time_ms,
            model_version=model_version
        )
        db.add(pred)
        db.commit()
        db.refresh(pred)
        return pred
    except Exception as e:
        db.rollback()
        print(f"Error storing prediction: {e}")
        return None
    finally:
        db.close()


def get_recent_predictions(limit: int = 100) -> List[SessionPrediction]:
    """Get recent predictions."""
    if SessionLocal is None:
        init_db()
    
    db = SessionLocal()
    try:
        return db.query(SessionPrediction)\
            .order_by(desc(SessionPrediction.created_at))\
            .limit(limit)\
            .all()
    finally:
        db.close()


def get_user_predictions(user: str, limit: int = 100) -> List[SessionPrediction]:
    """Get predictions for a specific user."""
    if SessionLocal is None:
        init_db()
    
    db = SessionLocal()
    try:
        return db.query(SessionPrediction)\
            .filter(SessionPrediction.user == user)\
            .order_by(desc(SessionPrediction.created_at))\
            .limit(limit)\
            .all()
    finally:
        db.close()


def get_alerts(limit: int = 100, include_suppressed: bool = False) -> List[SessionPrediction]:
    """Get recent alerts."""
    if SessionLocal is None:
        init_db()
    
    db = SessionLocal()
    try:
        query = db.query(SessionPrediction).filter(SessionPrediction.alert == True)
        
        if not include_suppressed:
            query = query.filter(SessionPrediction.suppressed == False)
        
        return query.order_by(desc(SessionPrediction.created_at)).limit(limit).all()
    finally:
        db.close()


def get_statistics() -> Dict[str, Any]:
    """Get overall statistics."""
    if SessionLocal is None:
        init_db()
    
    db = SessionLocal()
    try:
        total = db.query(SessionPrediction).count()
        alerts = db.query(SessionPrediction).filter(SessionPrediction.alert == True).count()
        suppressed = db.query(SessionPrediction).filter(SessionPrediction.suppressed == True).count()
        
        return {
            'total_predictions': total,
            'total_alerts': alerts,
            'suppressed_alerts': suppressed,
            'active_alerts': alerts - suppressed,
            'alert_rate': alerts / total if total > 0 else 0,
            'suppression_rate': suppressed / alerts if alerts > 0 else 0
        }
    finally:
        db.close()


if __name__ == '__main__':
    # Test database setup
    print("Initializing database...")
    init_db()
    print("✅ Database initialized")
    
    # Test storing a prediction
    pred = store_prediction(
        session_id='test_001',
        user='testuser',
        hybrid_prob=0.85,
        prediction=1,
        xgb_prob=0.82,
        lstm_prob=0.88,
        num_events=50,
        alert=True
    )
    
    if pred:
        print(f"✅ Stored prediction: {pred.to_dict()}")
    
    # Get statistics
    stats = get_statistics()
    print(f"✅ Statistics: {stats}")
