"""
Metrics collection for Insider Threat Detection System.

This module provides Prometheus-compatible metrics for monitoring:
- Request counts and rates
- Inference latency
- Model performance
- Alert rates
- Cache hit rates

Usage:
    from metrics import (
        inference_counter,
        inference_latency,
        alert_counter,
        record_inference
    )
    
    # Record an inference
    with record_inference('hybrid'):
        result = model.infer(...)
    
    # Increment alert counter
    if alert:
        alert_counter.inc()
"""

import time
from contextlib import contextmanager
from typing import Optional

try:
    from prometheus_client import Counter, Histogram, Gauge, Info, Summary
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    # Create dummy classes if prometheus not available
    class Counter:
        def __init__(self, *args, **kwargs): pass
        def labels(self, *args, **kwargs): return self
        def inc(self, *args, **kwargs): pass
    
    class Histogram:
        def __init__(self, *args, **kwargs): pass
        def labels(self, *args, **kwargs): return self
        def observe(self, *args, **kwargs): pass
    
    class Gauge:
        def __init__(self, *args, **kwargs): pass
        def set(self, *args, **kwargs): pass
        def inc(self, *args, **kwargs): pass
        def dec(self, *args, **kwargs): pass
    
    class Info:
        def __init__(self, *args, **kwargs): pass
        def info(self, *args, **kwargs): pass
    
    class Summary:
        def __init__(self, *args, **kwargs): pass
        def observe(self, *args, **kwargs): pass


# ===========================
# Request Metrics
# ===========================

# Total number of inference requests
inference_counter = Counter(
    'inference_requests_total',
    'Total number of inference requests',
    ['model_type', 'result']  # Labels: hybrid/xgb/lstm, success/error
)

# Inference latency histogram
inference_latency = Histogram(
    'inference_latency_seconds',
    'Inference latency in seconds',
    ['model_type'],
    buckets=[0.01, 0.05, 0.1, 0.5, 1.0, 2.0, 5.0]
)

# Batch size histogram
batch_size = Histogram(
    'batch_size',
    'Number of sessions in batch requests',
    buckets=[1, 5, 10, 50, 100, 500, 1000]
)

# Request size (number of events)
request_events = Histogram(
    'request_events',
    'Number of events per session',
    buckets=[1, 5, 10, 20, 50, 100, 200, 500, 1000]
)


# ===========================
# Model Performance Metrics
# ===========================

# Total alerts generated
alert_counter = Counter(
    'alerts_total',
    'Total number of alerts generated',
    ['suppressed']  # Labels: true/false
)

# Prediction probability distribution
prediction_probability = Histogram(
    'prediction_probability',
    'Distribution of prediction probabilities',
    ['model_type'],
    buckets=[0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
)

# Prediction results
prediction_result = Counter(
    'predictions_total',
    'Total predictions by class',
    ['prediction']  # Labels: 0=benign, 1=threat
)

# Model ensemble weights (info metric)
model_info = Info(
    'model_info',
    'Information about the model'
)


# ===========================
# Cache Metrics
# ===========================

# Cache hits and misses
cache_counter = Counter(
    'cache_requests_total',
    'Total cache requests',
    ['result']  # Labels: hit/miss
)

# Cache size gauge
cache_size = Gauge(
    'cache_size',
    'Current number of entries in cache'
)


# ===========================
# Database Metrics
# ===========================

# Database operations
db_operations = Counter(
    'database_operations_total',
    'Total database operations',
    ['operation', 'result']  # Labels: store/query, success/error
)

# Database query latency
db_latency = Histogram(
    'database_latency_seconds',
    'Database operation latency',
    ['operation'],
    buckets=[0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1.0]
)


# ===========================
# System Metrics
# ===========================

# Model load time
model_load_time = Gauge(
    'model_load_time_seconds',
    'Time taken to load model on startup'
)

# API uptime
api_uptime = Gauge(
    'api_uptime_seconds',
    'API uptime in seconds'
)

# Active requests
active_requests = Gauge(
    'active_requests',
    'Number of requests currently being processed'
)


# ===========================
# Helper Functions
# ===========================

@contextmanager
def record_inference(model_type: str = 'hybrid'):
    """
    Context manager to record inference metrics.
    
    Usage:
        with record_inference('hybrid'):
            result = model.infer(...)
    """
    start_time = time.time()
    active_requests.inc()
    
    try:
        yield
        # Success
        duration = time.time() - start_time
        inference_counter.labels(model_type=model_type, result='success').inc()
        inference_latency.labels(model_type=model_type).observe(duration)
    except Exception:
        # Error
        duration = time.time() - start_time
        inference_counter.labels(model_type=model_type, result='error').inc()
        inference_latency.labels(model_type=model_type).observe(duration)
        raise
    finally:
        active_requests.dec()


def record_prediction(prob: float, prediction: int, model_type: str = 'hybrid'):
    """Record prediction metrics."""
    prediction_probability.labels(model_type=model_type).observe(prob)
    prediction_result.labels(prediction=str(prediction)).inc()


def record_alert(suppressed: bool = False):
    """Record alert metric."""
    alert_counter.labels(suppressed=str(suppressed).lower()).inc()


def record_cache_hit(hit: bool):
    """Record cache hit/miss."""
    result = 'hit' if hit else 'miss'
    cache_counter.labels(result=result).inc()


def record_db_operation(operation: str, success: bool, duration: Optional[float] = None):
    """Record database operation."""
    result = 'success' if success else 'error'
    db_operations.labels(operation=operation, result=result).inc()
    
    if duration is not None:
        db_latency.labels(operation=operation).observe(duration)


def set_model_info(xgb_weight: float, lstm_weight: float, version: str):
    """Set model information."""
    model_info.info({
        'version': version,
        'xgb_weight': str(xgb_weight),
        'lstm_weight': str(lstm_weight),
        'type': 'hybrid_ensemble'
    })


# Initialize startup time
_startup_time = time.time()


def update_uptime():
    """Update API uptime metric."""
    uptime = time.time() - _startup_time
    api_uptime.set(uptime)


if __name__ == '__main__':
    # Test metrics
    if PROMETHEUS_AVAILABLE:
        print("✅ Prometheus metrics available")
        
        # Simulate some metrics
        with record_inference('hybrid'):
            time.sleep(0.1)
        
        record_prediction(0.75, 1, 'hybrid')
        record_alert(suppressed=False)
        record_cache_hit(True)
        
        print("✅ Metrics recorded successfully")
    else:
        print("⚠️  Prometheus client not installed - metrics disabled")
        print("Install with: pip install prometheus-client")
