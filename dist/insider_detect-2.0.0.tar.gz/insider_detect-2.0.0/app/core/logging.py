"""
Logging configuration for Insider Threat Detection System.

This module provides centralized logging setup with:
- Console and file handlers
- Configurable log levels
- Structured log format with timestamps
- Log rotation (10MB per file, keep 5 backups)

Usage:
    from logging_config import setup_logging
    
    logger = setup_logging('api')
    logger.info("Server starting")
    logger.error("Failed to load model: %s", error)
"""

import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler
from typing import Optional


def setup_logging(
    name: str,
    level: Optional[str] = None,
    log_dir: Optional[str] = None,
    console_enabled: bool = True,
    file_enabled: bool = True
) -> logging.Logger:
    """
    Configure logging with both file and console handlers.
    
    Args:
        name: Logger name (typically module name)
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_dir: Directory for log files. Defaults to 'logs'
        console_enabled: Enable console output
        file_enabled: Enable file output
        
    Returns:
        Configured logger instance
        
    Example:
        >>> logger = setup_logging('api', level='INFO')
        >>> logger.info("API started")
        >>> logger.debug("Detailed debug info")
    """
    # Import config here to avoid circular imports
    try:
        from app.core.config import config as cfg
        if level is None:
            level = cfg.get('logging.level', 'INFO')
        if log_dir is None:
            log_dir = cfg.get('paths.logs', 'logs')
    except ImportError:
        if level is None:
            level = 'INFO'
        if log_dir is None:
            log_dir = 'logs'
    
    # Create logs directory
    log_path = Path(log_dir)
    log_path.mkdir(exist_ok=True, parents=True)
    
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Console handler (INFO and above)
    if console_enabled:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_format = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        console_handler.setFormatter(console_format)
        logger.addHandler(console_handler)
    
    # File handler (DEBUG and above) with rotation
    if file_enabled:
        log_file = log_path / f'{name}.log'
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        file_format = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)
    
    # Prevent propagation to root logger
    logger.propagate = False
    
    return logger


def get_logger(name: str) -> logging.Logger:
    """
    Get or create a logger with standard configuration.
    
    Args:
        name: Logger name
        
    Returns:
        Logger instance
    """
    logger = logging.getLogger(name)
    
    # If logger has no handlers, set it up
    if not logger.handlers:
        return setup_logging(name)
    
    return logger


# Create default loggers for main modules
api_logger = setup_logging('api')
model_logger = setup_logging('model')
data_logger = setup_logging('data')


if __name__ == '__main__':
    # Test logging setup
    logger = setup_logging('test', level='DEBUG')
    
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")
    
    print("\nLog file created at: logs/test.log")
